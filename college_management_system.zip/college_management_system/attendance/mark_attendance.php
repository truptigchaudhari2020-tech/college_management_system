<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

$faculty_id = $_SESSION['user_id'];

$assign = $conn->query("
    SELECT course, subject 
    FROM faculty_subjects 
    WHERE faculty_id = $faculty_id
")->fetch_assoc();

$students = $conn->query("
    SELECT id, full_name 
    FROM users 
    WHERE role='student' AND course='{$assign['course']}'
");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    foreach ($_POST['status'] as $student_id => $status) {
        $stmt = $conn->prepare("
            INSERT INTO attendance
            (student_id, faculty_id, course, subject, attendance_date, status)
            VALUES (?, ?, ?, ?, CURDATE(), ?)
        ");
        $stmt->bind_param(
            "iisss",
            $student_id,
            $faculty_id,
            $assign['course'],
            $assign['subject'],
            $status
        );
        $stmt->execute();
    }
    echo "<script>alert('Attendance marked successfully');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mark Attendance</title>
</head>
<body>

<h2>Mark Attendance</h2>
<p><b>Course:</b> <?= $assign['course'] ?> | <b>Subject:</b> <?= $assign['subject'] ?></p>

<form method="POST">
<?php while ($s = $students->fetch_assoc()) { ?>
    <?= $s['full_name'] ?>
    <select name="status[<?= $s['id'] ?>]">
        <option value="Present">Present</option>
        <option value="Absent">Absent</option>
    </select>
    <br>
<?php } ?>

<br>
<button type="submit">Submit Attendance</button>
</form>

<br>
<a href="../faculty/dashboard.php">⬅ Back</a>

</body>
</html>
