<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$course = $_GET['course'] ?? '';

$sql = "
SELECT 
    a.attendance_date,
    a.status,
    a.subject,
    s.full_name AS student_name,
    f.full_name AS faculty_name,
    a.course
FROM attendance a
JOIN users s ON a.student_id = s.id
JOIN users f ON a.faculty_id = f.id
";

if ($course != '') {
    $sql .= " WHERE a.course='$course'";
}

$sql .= " ORDER BY a.attendance_date DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance List</title>
</head>
<body>

<h2>Attendance Records</h2>

<form method="GET">
    <select name="course">
        <option value="">All Courses</option>
        <option>MCA</option>
        <option>MSC</option>
        <option>BCA</option>
        <option>BSC</option>
    </select>
    <button type="submit">Filter</button>
</form>

<br>

<table border="1" cellpadding="8">
<tr>
    <th>Date</th>
    <th>Student</th>
    <th>Faculty</th>
    <th>Course</th>
    <th>Subject</th>
    <th>Status</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['attendance_date'] ?></td>
    <td><?= $row['student_name'] ?></td>
    <td><?= $row['faculty_name'] ?></td>
    <td><?= $row['course'] ?></td>
    <td><?= $row['subject'] ?></td>
    <td><?= $row['status'] ?></td>
</tr>
<?php } ?>

</table>

<br>
<a href="../admin/dashboard.php">⬅ Back</a>

</body>
</html>
