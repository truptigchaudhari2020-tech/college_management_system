<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

$student_id = $_SESSION['user_id'];

$result = $conn->query("
    SELECT subject, marks, grade
    FROM results
    WHERE student_id = $student_id
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Results</title>
</head>
<body>

<h2>My Exam Results</h2>

<table border="1" cellpadding="8">
<tr>
    <th>Subject</th>
    <th>Marks</th>
    <th>Grade</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['subject'] ?></td>
    <td><?= $row['marks'] ?></td>
    <td><?= $row['grade'] ?></td>
</tr>
<?php } ?>

</table>

<br>
<a href="../student/dashboard.php">⬅ Back</a>

</body>
</html>
