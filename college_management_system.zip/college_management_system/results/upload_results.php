<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

$faculty_id = $_SESSION['user_id'];

// Get assigned course & subject
$assign = $conn->query("
    SELECT course, subject 
    FROM faculty_subjects 
    WHERE faculty_id = $faculty_id
")->fetch_assoc();

// Get students of assigned course
$students = $conn->query("
    SELECT id, full_name 
    FROM users 
    WHERE role='student' AND course='{$assign['course']}'
");

$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $student_id = $_POST['student_id'];
    $marks = (int)$_POST['marks'];

    // Grade logic
    if ($marks >= 75) $grade = "A";
    elseif ($marks >= 60) $grade = "B";
    elseif ($marks >= 40) $grade = "C";
    else $grade = "F";

    $stmt = $conn->prepare("
        INSERT INTO results (student_id, course, subject, marks, grade)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "issis",
        $student_id,
        $assign['course'],
        $assign['subject'],
        $marks,
        $grade
    );
    $stmt->execute();

    $msg = "Result uploaded successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Results</title>
</head>
<body>

<h2>Upload Results</h2>

<p>
<b>Course:</b> <?= $assign['course'] ?> |
<b>Subject:</b> <?= $assign['subject'] ?>
</p>

<form method="POST">
    <select name="student_id" required>
        <option value="">Select Student</option>
        <?php while ($s = $students->fetch_assoc()) { ?>
            <option value="<?= $s['id'] ?>"><?= $s['full_name'] ?></option>
        <?php } ?>
    </select><br><br>

    <input type="number" name="marks" placeholder="Marks (0–100)" min="0" max="100" required><br><br>

    <button type="submit">Upload Result</button>
</form>

<p><?= $msg ?></p>

<a href="../faculty/dashboard.php">⬅ Back</a>

</body>
</html>
