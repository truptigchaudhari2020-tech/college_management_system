<?php
$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $msg = "Password reset link sent to your email (demo).";
}
?>
<!DOCTYPE html>
<html>
<head><title>Forgot Password</title></head>
<body>
<h2>Forgot Password</h2>
<form method="POST">
<input type="email" placeholder="Enter Email" required>
<button>Submit</button>
</form>
<p><?= $msg ?></p>
</body>
</html>
