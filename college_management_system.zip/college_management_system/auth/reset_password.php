<!DOCTYPE html>
<html>
<head><title>Reset Password</title></head>
<body>
<h2>Reset Password</h2>
<form>
<input type="password" placeholder="New Password" required><br><br>
<input type="password" placeholder="Confirm Password" required><br><br>
<button>Reset</button>
</form>
</body>
</html>
