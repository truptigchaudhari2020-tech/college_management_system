<?php
require_once "../config/db.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $course = $_POST['course'];
    $caste = $_POST['caste'];

    $stmt = $conn->prepare(
        "INSERT INTO users 
        (full_name, dob, mobile, email, username, password, role, course, caste_category) 
        VALUES (?,?,?,?,?,?,'student',?,?)"
    );

    if ($stmt->bind_param("ssssssss", 
        $full_name, $dob, $mobile, $email, $username, $password, $course, $caste
    ) && $stmt->execute()) {
        $msg = "Registration successful! You can login now.";
    } else {
        $msg = "Registration failed. Email or Username already exists.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-icon">🎓</div>
            <h2>Student Registration</h2>
            <p>Create your account to get started</p>
        </div>

        <form method="POST" class="auth-form">
            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">👤</span>
                    <input type="text" name="full_name" placeholder="Full Name" required>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">📅</span>
                    <input type="date" name="dob" placeholder="Date of Birth" required>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">📱</span>
                    <input type="text" name="mobile" placeholder="Mobile Number" required>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">📧</span>
                    <input type="email" name="email" placeholder="Email Address" required>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">🔤</span>
                    <input type="text" name="username" placeholder="Username" required>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">🔒</span>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">📚</span>
                    <select name="course" required>
                        <option value="">Select Course</option>
                        <option>MCA</option>
                        <option>MSC</option>
                        <option>BCA</option>
                        <option>BSC</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">🏷️</span>
                    <select name="caste" required>
                        <option value="">Caste Category</option>
                        <option>Open</option>
                        <option>OBC</option>
                        <option>SC</option>
                        <option>ST</option>
                        <option>NT</option>
                        <option>VJNT</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="submit-btn">
                <span>Register</span>
                <span class="btn-arrow">→</span>
            </button>

            <?php if ($msg): ?>
                <div class="message <?= strpos($msg, 'successful') !== false ? 'success' : 'error' ?>">
                    <?= $msg ?>
                </div>
            <?php endif; ?>
        </form>

        <div class="auth-footer">
            <p>Already have an account? <a href="login.php">Login here</a></p>
            <a href="../index.php" class="back-link">← Back to Home</a>
        </div>
    </div>
</div>

</body>
</html>