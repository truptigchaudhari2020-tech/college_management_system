<?php
session_start();
require_once "../config/db.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = trim($_POST['login']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=? OR email=? LIMIT 1");
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['full_name'];

            if ($user['role'] === 'admin') {
                header("Location: ../admin/dashboard.php");
            } elseif ($user['role'] === 'faculty') {
                header("Location: ../faculty/dashboard.php");
            } else {
                header("Location: ../student/dashboard.php");
            }
            exit;
        }
    }
    $error = "Invalid login credentials!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - College Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="auth-container">
    <div class="auth-card login-card">
        <div class="auth-header">
            <div class="auth-icon">🔐</div>
            <h2>Welcome Back</h2>
            <p>Login to access your dashboard</p>
        </div>

        <form method="POST" class="auth-form">
            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">👤</span>
                    <input type="text" name="login" placeholder="Username or Email" required>
                </div>
            </div>

            <div class="form-row">
                <div class="input-group">
                    <span class="input-icon">🔒</span>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
            </div>

            <button type="submit" class="submit-btn">
                <span>Login</span>
                <span class="btn-arrow">→</span>
            </button>

            <?php if ($error): ?>
                <div class="message error">
                    <?= $error ?>
                </div>
            <?php endif; ?>
        </form>

        <div class="auth-footer">
            <p>Don't have an account? <a href="student_register.php">Register here</a></p>
            <a href="../index.php" class="back-link">← Back to Home</a>
        </div>
    </div>
</div>

</body>
</html>