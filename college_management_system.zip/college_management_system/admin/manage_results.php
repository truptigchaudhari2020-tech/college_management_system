<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$result = $conn->query("
SELECT 
    r.subject, r.marks, r.grade,
    u.full_name AS student_name,
    r.course
FROM results r
JOIN users u ON r.student_id = u.id
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Results</title>
</head>
<body>

<h2>Student Results</h2>

<table border="1" cellpadding="8">
<tr>
    <th>Student</th>
    <th>Course</th>
    <th>Subject</th>
    <th>Marks</th>
    <th>Grade</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['student_name'] ?></td>
    <td><?= $row['course'] ?></td>
    <td><?= $row['subject'] ?></td>
    <td><?= $row['marks'] ?></td>
    <td><?= $row['grade'] ?></td>
</tr>
<?php } ?>

</table>

<br>
<a href="dashboard.php">⬅ Back</a>

</body>
</html>
