<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$msg = "";
$msgType = "";

/* ADD BOOK */
if (isset($_POST['add_book'])) {
    $book   = $_POST['book_name'];
    $author = $_POST['author'];
    $course = $_POST['course'];
    $qty    = $_POST['quantity'];

    $stmt = $conn->prepare(
        "INSERT INTO library_books (book_name, author, course, quantity)
         VALUES (?,?,?,?)"
    );
    $stmt->bind_param("sssi", $book, $author, $course, $qty);
    $stmt->execute();

    $msg = "Book added successfully to the library!";
    $msgType = "success";
}

/* ASSIGN BOOK TO STUDENT */
if (isset($_POST['assign_book'])) {
    $book_id    = $_POST['book_id'];
    $student_id = $_POST['student_id'];

    // Issue date = today | Return date = +3 days
    $conn->query("
        INSERT INTO book_issue (book_id, student_id, issue_date, return_date, status)
        VALUES ($book_id, $student_id, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 3 DAY), 'Issued')
    ");

    // Reduce quantity
    $conn->query("
        UPDATE library_books SET quantity = quantity - 1 WHERE id = $book_id
    ");

    $msg = "Book assigned successfully! Return date: " . date('d M Y', strtotime('+3 days'));
    $msgType = "success";
}

// Filters
$courseFilter = $_GET['course'] ?? '';
$searchQuery = $_GET['search'] ?? '';

/* FETCH DATA */
$booksSql = "SELECT * FROM library_books WHERE 1=1";

if ($courseFilter != '') {
    $booksSql .= " AND course='$courseFilter'";
}

if ($searchQuery != '') {
    $booksSql .= " AND (book_name LIKE '%$searchQuery%' OR author LIKE '%$searchQuery%')";
}

$booksSql .= " ORDER BY book_name";

$books     = $conn->query($booksSql);
$books_av  = $conn->query("SELECT * FROM library_books WHERE quantity > 0 ORDER BY book_name");
$students  = $conn->query("SELECT id, full_name, course FROM users WHERE role='student' ORDER BY full_name");

// Get statistics
$totalBooks = $conn->query("SELECT SUM(quantity) as total FROM library_books")->fetch_assoc()['total'] ?? 0;
$uniqueBooks = $conn->query("SELECT COUNT(*) as count FROM library_books")->fetch_assoc()['count'];
$issuedBooks = $conn->query("SELECT COUNT(*) as count FROM book_issue WHERE status='Issued'")->fetch_assoc()['count'];
$availableBooks = $totalBooks - $issuedBooks;

// Get issued books list
$issuedBooksList = $conn->query("
    SELECT 
        bi.id,
        lb.book_name,
        u.full_name as student_name,
        bi.issue_date,
        bi.return_date,
        DATEDIFF(bi.return_date, CURDATE()) as days_left
    FROM book_issue bi
    JOIN library_books lb ON bi.book_id = lb.id
    JOIN users u ON bi.student_id = u.id
    WHERE bi.status = 'Issued'
    ORDER BY bi.return_date ASC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Library</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            animation: fadeIn 0.5s ease;
        }

        .container {
            max-width: 1300px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: slideDown 0.6s ease;
        }

        .header h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header .icon {
            font-size: 48px;
            margin-bottom: 10px;
            display: inline-block;
        }

        /* Alert Messages */
        .alert {
            background: white;
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: slideDown 0.5s ease;
        }

        .alert.success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
        }

        .alert-icon {
            font-size: 24px;
        }

        /* Statistics Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
            animation: slideUp 0.7s ease;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 13px;
            color: #718096;
            font-weight: 500;
        }

        .stat-card.total { border-left: 4px solid #667eea; }
        .stat-card.unique { border-left: 4px solid #9f7aea; }
        .stat-card.issued { border-left: 4px solid #ed8936; }
        .stat-card.available { border-left: 4px solid #48bb78; }

        /* Two Column Layout */
        .two-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 24px;
        }

        /* Card Styles */
        .card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            animation: scaleIn 0.6s ease;
        }

        .card-title {
            font-size: 18px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 6px;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: #f8fafc;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn {
            width: 100%;
            padding: 12px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin-top: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }

        .btn-success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
        }

        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(72, 187, 120, 0.4);
        }

        .note {
            background: #f7fafc;
            border-left: 3px solid #4299e1;
            padding: 10px 12px;
            border-radius: 8px;
            font-size: 13px;
            color: #4a5568;
            margin-top: 12px;
        }

        /* Filter Section */
        .filter-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 24px;
            animation: scaleIn 0.7s ease;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 16px;
            margin-bottom: 16px;
        }

        .filter-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn-secondary {
            padding: 10px 20px;
            background: #e2e8f0;
            color: #2d3748;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-secondary:hover {
            background: #cbd5e0;
        }

        .btn-export {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
        }

        /* Table Styles */
        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f7fafc;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #2d3748;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 14px 12px;
            color: #4a5568;
            font-size: 14px;
            border-bottom: 1px solid #f1f5f9;
        }

        tr:hover {
            background: #f8fafc;
        }

        .course-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-mca { background: #c6f6d5; color: #22543d; }
        .badge-msc { background: #feebc8; color: #7c2d12; }
        .badge-bca { background: #bee3f8; color: #1e4e8c; }
        .badge-bsc { background: #e9d8fd; color: #44337a; }

        .qty-badge {
            display: inline-block;
            padding: 4px 12px;
            background: #48bb78;
            color: white;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .qty-badge.low {
            background: #ed8936;
        }

        .qty-badge.out {
            background: #f56565;
        }

        .days-left {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
        }

        .days-left.safe {
            background: #c6f6d5;
            color: #22543d;
        }

        .days-left.warning {
            background: #feebc8;
            color: #7c2d12;
        }

        .days-left.danger {
            background: #fed7d7;
            color: #742a2a;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 24px;
            padding: 12px 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-4px);
        }

        /* Mobile Cards */
        .mobile-cards {
            display: none;
        }

        .book-card-mobile {
            background: white;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }

        .card-header-mobile {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .book-title {
            font-weight: 700;
            color: #2d3748;
            font-size: 15px;
        }

        .card-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
        }

        .card-label {
            color: #718096;
            font-weight: 500;
        }

        .card-value {
            color: #2d3748;
            font-weight: 600;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Responsive */
        @media (max-width: 968px) {
            .two-column {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .header h2 {
                font-size: 24px;
            }

            .stats-container {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }

            .filter-grid {
                grid-template-columns: 1fr;
            }

            .filter-actions {
                flex-direction: column;
            }

            .btn-secondary,
            .btn-export {
                width: 100%;
                justify-content: center;
            }

            .table-responsive {
                display: none;
            }

            .mobile-cards {
                display: block;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="icon">📚</div>
        <h2>Library Management</h2>
    </div>

    <!-- Alert Message -->
    <?php if ($msg): ?>
    <div class="alert <?= $msgType ?>">
        <span class="alert-icon">✓</span>
        <span><?= htmlspecialchars($msg) ?></span>
    </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-container">
        <div class="stat-card total">
            <div class="stat-icon">📖</div>
            <div class="stat-value"><?= $totalBooks ?></div>
            <div class="stat-label">Total Books</div>
        </div>
        <div class="stat-card unique">
            <div class="stat-icon">📕</div>
            <div class="stat-value"><?= $uniqueBooks ?></div>
            <div class="stat-label">Unique Titles</div>
        </div>
        <div class="stat-card issued">
            <div class="stat-icon">📤</div>
            <div class="stat-value"><?= $issuedBooks ?></div>
            <div class="stat-label">Books Issued</div>
        </div>
        <div class="stat-card available">
            <div class="stat-icon">✅</div>
            <div class="stat-value"><?= $availableBooks ?></div>
            <div class="stat-label">Available</div>
        </div>
    </div>

    <!-- Two Column Layout: Add Book & Assign Book -->
    <div class="two-column">
        <!-- ADD BOOK CARD -->
        <div class="card">
            <div class="card-title">➕ Add New Book</div>
            <form method="POST">
                <div class="form-group">
                    <label>Book Name</label>
                    <input type="text" name="book_name" placeholder="Enter book title..." required>
                </div>

                <div class="form-group">
                    <label>Author</label>
                    <input type="text" name="author" placeholder="Author name..." required>
                </div>

                <div class="form-group">
                    <label>Course</label>
                    <select name="course" required>
                        <option value="">Select Course</option>
                        <option>MCA</option>
                        <option>MSC</option>
                        <option>BCA</option>
                        <option>BSC</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Quantity</label>
                    <input type="number" name="quantity" min="1" placeholder="Number of copies..." required>
                </div>

                <button type="submit" name="add_book" class="btn btn-primary">
                    ➕ Add Book to Library
                </button>
            </form>
        </div>

        <!-- ASSIGN BOOK CARD -->
        <div class="card">
            <div class="card-title">📤 Issue Book to Student</div>
            <form method="POST">
                <div class="form-group">
                    <label>Select Book</label>
                    <select name="book_id" required>
                        <option value="">Choose available book...</option>
                        <?php while ($b = $books_av->fetch_assoc()) { ?>
                            <option value="<?= $b['id'] ?>">
                                <?= htmlspecialchars($b['book_name']) ?> (<?= $b['course'] ?>) - Qty: <?= $b['quantity'] ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Select Student</label>
                    <select name="student_id" required>
                        <option value="">Choose student...</option>
                        <?php while ($s = $students->fetch_assoc()) { ?>
                            <option value="<?= $s['id'] ?>">
                                <?= htmlspecialchars($s['full_name']) ?> (<?= $s['course'] ?>)
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <button type="submit" name="assign_book" class="btn btn-success">
                    📤 Issue Book
                </button>

                <div class="note">
                    📌 <strong>Note:</strong> Return date will be automatically set to 3 days from today.
                </div>
            </form>
        </div>
    </div>

    <!-- Currently Issued Books -->
    <?php if ($issuedBooksList->num_rows > 0): ?>
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-title">📋 Currently Issued Books</div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Book Name</th>
                        <th>Student</th>
                        <th>Issue Date</th>
                        <th>Return Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($issued = $issuedBooksList->fetch_assoc()): 
                        $daysLeft = $issued['days_left'];
                        $statusClass = $daysLeft > 2 ? 'safe' : ($daysLeft >= 0 ? 'warning' : 'danger');
                        $statusText = $daysLeft > 0 ? "$daysLeft days left" : ($daysLeft == 0 ? "Due today" : "Overdue!");
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($issued['book_name']) ?></td>
                        <td><?= htmlspecialchars($issued['student_name']) ?></td>
                        <td><?= date('d M Y', strtotime($issued['issue_date'])) ?></td>
                        <td><?= date('d M Y', strtotime($issued['return_date'])) ?></td>
                        <td>
                            <span class="days-left <?= $statusClass ?>">
                                <?= $statusText ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- Filter Section -->
    <div class="filter-card">
        <div class="card-title">🔍 Search & Filter Books</div>
        <form method="GET">
            <div class="filter-grid">
                <div class="form-group">
                    <label>Search by Book Name or Author</label>
                    <input type="text" name="search" placeholder="Search books..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                <div class="form-group">
                    <label>Filter by Course</label>
                    <select name="course">
                        <option value="">All Courses</option>
                        <option <?= $courseFilter == 'MCA' ? 'selected' : '' ?>>MCA</option>
                        <option <?= $courseFilter == 'MSC' ? 'selected' : '' ?>>MSC</option>
                        <option <?= $courseFilter == 'BCA' ? 'selected' : '' ?>>BCA</option>
                        <option <?= $courseFilter == 'BSC' ? 'selected' : '' ?>>BSC</option>
                    </select>
                </div>
            </div>
            <div class="filter-actions">
                <button type="submit" class="btn-secondary">🔍 Apply Filter</button>
                <a href="manage_library.php" class="btn-secondary">🔄 Reset</a>
                <button type="button" onclick="exportToCSV()" class="btn-export">📥 Export CSV</button>
            </div>
        </form>
    </div>

    <!-- Books List -->
    <div class="card">
        <div class="card-title">📚 All Library Books</div>

        <!-- Desktop Table -->
        <div class="table-responsive">
            <table id="booksTable">
                <thead>
                    <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Course</th>
                        <th>Available Qty</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $books->fetch_assoc()): 
                        $qtyClass = $row['quantity'] > 5 ? '' : ($row['quantity'] > 0 ? 'low' : 'out');
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($row['book_name']) ?></td>
                        <td><?= htmlspecialchars($row['author']) ?></td>
                        <td>
                            <span class="course-badge badge-<?= strtolower($row['course']) ?>">
                                <?= $row['course'] ?>
                            </span>
                        </td>
                        <td>
                            <span class="qty-badge <?= $qtyClass ?>">
                                <?= $row['quantity'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Mobile Cards -->
        <div class="mobile-cards">
            <?php 
            $books->data_seek(0);
            while ($row = $books->fetch_assoc()): 
                $qtyClass = $row['quantity'] > 5 ? '' : ($row['quantity'] > 0 ? 'low' : 'out');
            ?>
            <div class="book-card-mobile">
                <div class="card-header-mobile">
                    <div class="book-title"><?= htmlspecialchars($row['book_name']) ?></div>
                    <span class="course-badge badge-<?= strtolower($row['course']) ?>">
                        <?= $row['course'] ?>
                    </span>
                </div>
                <div class="card-row">
                    <span class="card-label">Author:</span>
                    <span class="card-value"><?= htmlspecialchars($row['author']) ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Available:</span>
                    <span class="qty-badge <?= $qtyClass ?>">
                        <?= $row['quantity'] ?>
                    </span>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>

    <center>
        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </center>
</div>

<script>
function exportToCSV() {
    let csv = 'Book Name,Author,Course,Available Quantity\n';
    const table = document.getElementById('booksTable');
    
    if (!table) {
        alert('No data to export');
        return;
    }
    
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        const rowData = [];
        
        cols.forEach(col => {
            let text = col.textContent.trim();
            text = text.replace(/\s+/g, ' ');
            rowData.push('"' + text + '"');
        });
        
        csv += rowData.join(',') + '\n';
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'library_books_' + new Date().toISOString().split('T')[0] + '.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}
</script>

</body>
</html>