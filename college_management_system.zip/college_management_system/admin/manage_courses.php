<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

// Get statistics for each course
$courses = [
    'MCA' => ['icon' => '💻', 'name' => 'Master of Computer Applications', 'color' => '#48bb78'],
    'MSC' => ['icon' => '🔬', 'name' => 'Master of Science', 'color' => '#ed8936'],
    'BCA' => ['icon' => '🖥️', 'name' => 'Bachelor of Computer Applications', 'color' => '#4299e1'],
    'BSC' => ['icon' => '🧪', 'name' => 'Bachelor of Science', 'color' => '#9f7aea']
];

$courseStats = [];
foreach ($courses as $code => $info) {
    $studentCount = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='student' AND course='$code'")->fetch_assoc()['count'];
    $facultyCount = $conn->query("SELECT COUNT(DISTINCT faculty_id) as count FROM faculty_subjects WHERE course='$code'")->fetch_assoc()['count'];
    $subjectCount = $conn->query("SELECT COUNT(*) as count FROM subjects WHERE course='$code'")->fetch_assoc()['count'];
    
    $courseStats[$code] = [
        'students' => $studentCount,
        'faculty' => $facultyCount,
        'subjects' => $subjectCount
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            animation: fadeIn 0.5s ease;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: slideDown 0.6s ease;
        }

        .header h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header .icon {
            font-size: 48px;
            margin-bottom: 10px;
            display: inline-block;
        }

        .header p {
            font-size: 14px;
            opacity: 0.95;
            margin-top: 8px;
        }

        /* Info Card */
        .info-card {
            background: white;
            border-radius: 20px;
            padding: 20px 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 24px;
            animation: scaleIn 0.6s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid #4299e1;
        }

        .info-icon {
            font-size: 24px;
        }

        .info-text {
            color: #4a5568;
            font-size: 14px;
            line-height: 1.6;
        }

        /* Course Grid */
        .courses-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
            animation: slideUp 0.7s ease;
        }

        .course-card {
            background: white;
            border-radius: 20px;
            padding: 28px 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .course-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--course-color), var(--course-color-light));
        }

        .course-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.25);
        }

        .course-card:nth-child(1) {
            --course-color: #48bb78;
            --course-color-light: #68d391;
            animation-delay: 0.1s;
        }

        .course-card:nth-child(2) {
            --course-color: #ed8936;
            --course-color-light: #f6ad55;
            animation-delay: 0.2s;
        }

        .course-card:nth-child(3) {
            --course-color: #4299e1;
            --course-color-light: #63b3ed;
            animation-delay: 0.3s;
        }

        .course-card:nth-child(4) {
            --course-color: #9f7aea;
            --course-color-light: #b794f4;
            animation-delay: 0.4s;
        }

        .course-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 16px;
        }

        .course-icon {
            font-size: 48px;
            transition: transform 0.3s ease;
        }

        .course-card:hover .course-icon {
            transform: scale(1.2) rotate(5deg);
        }

        .course-info {
            flex: 1;
        }

        .course-code {
            font-size: 24px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 4px;
        }

        .course-name {
            font-size: 13px;
            color: #718096;
            font-weight: 500;
            line-height: 1.4;
        }

        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: var(--course-color);
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 11px;
            color: #718096;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Quick Actions */
        .actions-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 24px;
            animation: scaleIn 0.8s ease;
        }

        .actions-title {
            font-size: 18px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
        }

        .action-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 14px 18px;
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            color: #2d3748;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .action-btn:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        .action-icon {
            font-size: 20px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 24px;
            padding: 12px 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-4px);
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Pulse Animation for Stats */
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .stat-value {
            animation: pulse 2s ease-in-out infinite;
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .header h2 {
                font-size: 24px;
            }

            .header .icon {
                font-size: 40px;
            }

            .courses-grid {
                grid-template-columns: 1fr;
                gap: 16px;
            }

            .course-card {
                padding: 24px 20px;
            }

            .course-icon {
                font-size: 40px;
            }

            .course-code {
                font-size: 20px;
            }

            .course-name {
                font-size: 12px;
            }

            .stats-row {
                gap: 8px;
            }

            .stat-value {
                font-size: 20px;
            }

            .actions-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 400px) {
            .info-card {
                flex-direction: column;
                text-align: center;
            }

            .stats-row {
                grid-template-columns: 1fr;
                gap: 12px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="icon">📘</div>
        <h2>Course Management</h2>
        <p>University Approved Programs</p>
    </div>

    <!-- Info Card -->
    <div class="info-card">
        <span class="info-icon">ℹ️</span>
        <p class="info-text">
            <strong>Note:</strong> These courses are predefined as per university curriculum and cannot be modified. 
            Each course has its own subjects, faculty assignments, and student enrollment.
        </p>
    </div>

    <!-- Courses Grid -->
    <div class="courses-grid">
        <?php foreach ($courses as $code => $info): ?>
        <div class="course-card">
            <div class="course-header">
                <span class="course-icon"><?= $info['icon'] ?></span>
                <div class="course-info">
                    <div class="course-code"><?= $code ?></div>
                    <div class="course-name"><?= $info['name'] ?></div>
                </div>
            </div>

            <div class="stats-row">
                <div class="stat-item">
                    <div class="stat-value"><?= $courseStats[$code]['students'] ?></div>
                    <div class="stat-label">Students</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?= $courseStats[$code]['faculty'] ?></div>
                    <div class="stat-label">Faculty</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?= $courseStats[$code]['subjects'] ?></div>
                    <div class="stat-label">Subjects</div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Quick Actions -->
    <div class="actions-card">
        <div class="actions-title">⚡ Quick Actions</div>
        <div class="actions-grid">
            <a href="manage_subjects.php" class="action-btn">
                <span class="action-icon">📗</span>
                <span>Manage Subjects</span>
            </a>
            <a href="manage_students.php" class="action-btn">
                <span class="action-icon">🎓</span>
                <span>View Students</span>
            </a>
            <a href="manage_faculty.php" class="action-btn">
                <span class="action-icon">👨‍🏫</span>
                <span>View Faculty</span>
            </a>
            <a href="assign_course_subject.php" class="action-btn">
                <span class="action-icon">📌</span>
                <span>Assign Courses</span>
            </a>
        </div>
    </div>

    <center>
        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </center>
</div>

</body>
</html>