<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$msg = "";

$faculty = $conn->query("SELECT id, full_name FROM users WHERE role='faculty'");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $faculty_id = $_POST['faculty_id'];
    $course = $_POST['course'];
    $subject = $_POST['subject'];

    $conn->query("DELETE FROM faculty_subjects WHERE faculty_id=$faculty_id");

    $stmt = $conn->prepare(
        "INSERT INTO faculty_subjects (faculty_id, course, subject) VALUES (?,?,?)"
    );
    $stmt->bind_param("iss", $faculty_id, $course, $subject);
    $stmt->execute();

    $msg = "Course & Subject Assigned Successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Course & Subject</title>
</head>
<body>

<h2>Assign Course & Subject</h2>

<form method="POST">
<select name="faculty_id" required>
    <option value="">Select Faculty</option>
    <?php while ($f = $faculty->fetch_assoc()) { ?>
        <option value="<?= $f['id'] ?>"><?= $f['full_name'] ?></option>
    <?php } ?>
</select><br><br>

<select name="course" required>
    <option>MCA</option>
    <option>MSC</option>
    <option>BCA</option>
    <option>BSC</option>
</select><br><br>

<input name="subject" placeholder="Subject Name" required><br><br>

<button type="submit">Assign</button>
</form>

<p><?= $msg ?></p>
<a href="dashboard.php">⬅ Back</a>

</body>
</html>
