<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

if (!isset($_GET['id'])) {
    die("Faculty ID missing!");
}

$faculty_id = intval($_GET['id']);

/* FETCH FACULTY DETAILS */
$faculty = $conn->query("
    SELECT * FROM users 
    WHERE id=$faculty_id AND role='faculty'
")->fetch_assoc();

if (!$faculty) {
    die("Faculty not found!");
}

/* SAVE UPDATED DATA */
$msg = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name  = $_POST['full_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $qualification = $_POST['qualification'];
    $username = $_POST['username'];

    // Multiple courses → string
    $courses = implode(",", $_POST['courses']);

    // Update faculty info
    $stmt = $conn->prepare("
        UPDATE users
        SET full_name=?, email=?, mobile=?, qualification=?, username=?, courses=?
        WHERE id=? AND role='faculty'
    ");

    $stmt->bind_param(
        "ssssssi",
        $name, $email, $mobile,
        $qualification, $username,
        $courses, $faculty_id
    );

    if ($stmt->execute()) {
        $msg = "Faculty details updated successfully!";
    } else {
        $error = "❌ Update failed. Email or username may already exist!";
    }
}

// Handle multi-course selected values
$selected_courses = explode(",", $faculty['courses']);
function checked($arr, $value) {
    return in_array($value, $arr) ? "checked" : "";
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Faculty</title>

<style>
    body { font-family: Arial; padding: 20px; }
    label { font-weight: bold; }
    .box { width: 50%; background: #f5f5f5; padding: 20px; border-radius: 8px; }
    input[type=text], input[type=password], input[type=email] {
        width: 100%; padding: 10px; margin: 5px 0;
        border-radius: 4px; border: 1px solid #aaa;
    }
    button {
        padding: 10px 15px; background: #333; color:#fff;
        border: none; border-radius: 4px; cursor:pointer;
    }
    button:hover { background:#000; }
</style>

</head>
<body>

<h2>✏️ Edit Faculty Details</h2>

<?php if ($msg) { ?>
    <p style="color:green; font-weight:bold;"><?= $msg ?></p>
<?php } ?>

<?php if ($error) { ?>
    <p style="color:red; font-weight:bold;"><?= $error ?></p>
<?php } ?>

<div class="box">

<form method="POST">

<label>Full Name</label>
<input name="full_name" value="<?= $faculty['full_name'] ?>" required>

<label>Email</label>
<input type="email" name="email" value="<?= $faculty['email'] ?>" required>

<label>Mobile Number</label>
<input name="mobile" value="<?= $faculty['mobile'] ?>" required>

<label>Qualification</label>
<input name="qualification" value="<?= $faculty['qualification'] ?>" required>

<label>Username</label>
<input name="username" value="<?= $faculty['username'] ?>" required>

<label>Courses Teaching</label><br>
<input type="checkbox" name="courses[]" value="MCA" <?= checked($selected_courses, "MCA") ?>> MCA<br>
<input type="checkbox" name="courses[]" value="MSC" <?= checked($selected_courses, "MSC") ?>> MSC<br>
<input type="checkbox" name="courses[]" value="BCA" <?= checked($selected_courses, "BCA") ?>> BCA<br>
<input type="checkbox" name="courses[]" value="BSC" <?= checked($selected_courses, "BSC") ?>> BSC<br><br>

<button type="submit">Update Faculty</button>

</form>
</div>

<br>
<a href="manage_faculty.php">⬅ Back</a>

</body>
</html>
