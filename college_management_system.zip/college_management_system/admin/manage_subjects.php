<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
require_once "../config/mailer.php";  // <-- EMAIL
checkRole('admin');

$msg = "";

/* ADD SUBJECT */
if (isset($_POST['add_subject'])) {
    $subject = $_POST['subject_name'];
    $course  = $_POST['course'];

    $stmt = $conn->prepare("
        INSERT INTO subjects (subject_name, course)
        VALUES (?, ?)
    ");
    $stmt->bind_param("ss", $subject, $course);
    $stmt->execute();

    $msg = "Subject added successfully!";
}

/* DELETE SUBJECT */
if (isset($_GET['delete_subject'])) {
    $id = (int)$_GET['delete_subject'];

    $conn->query("DELETE FROM faculty_subjects WHERE subject_id=$id");
    $conn->query("DELETE FROM subjects WHERE id=$id");

    header("Location: manage_subjects.php");
    exit;
}

/* ASSIGN SUBJECT TO FACULTY */
if (isset($_POST['assign_subject'])) {

    $faculty_id = $_POST['faculty_id'];
    $subject_id = $_POST['subject_id'];

    // Get subject details
    $sub = $conn->query("
        SELECT subject_name, course
        FROM subjects
        WHERE id=$subject_id
    ")->fetch_assoc();

    $subject_name = $sub['subject_name'];
    $course       = $sub['course'];

    // Faculty details
    $fac = $conn->query("
        SELECT full_name, email 
        FROM users 
        WHERE id=$faculty_id
    ")->fetch_assoc();

    $faculty_name  = $fac['full_name'];
    $faculty_email = $fac['email'];

    // Prevent duplicate assignment
    $exists = $conn->query("
        SELECT id FROM faculty_subjects
        WHERE faculty_id=$faculty_id AND subject_id=$subject_id
    ");

    if ($exists->num_rows > 0) {
        $msg = "⚠️ This subject is already assigned to $faculty_name!";
    } else {

        // Assign subject
        $stmt = $conn->prepare("
            INSERT INTO faculty_subjects (faculty_id, course, subject, subject_id)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("issi", $faculty_id, $course, $subject_name, $subject_id);
        $stmt->execute();

        /* 📩 EMAIL NOTIFICATION */
        $email_subject = "New Subject Assigned – $subject_name ($course)";

        $email_body = "
            <h2>New Subject Assigned</h2>

            <p>Hello <b>$faculty_name</b>,</p>

            <p>You have been assigned a new subject.</p>

            <h3>Subject Details:</h3>
            <table border='1' cellpadding='8'>
                <tr><td><b>Subject</b></td><td>$subject_name</td></tr>
                <tr><td><b>Course</b></td><td>$course</td></tr>
            </table>

            <p>Please check your Faculty Dashboard → My Subjects.</p>

            <p>Regards,<br>
            <b>College Management System</b></p>
        ";

        sendMail($faculty_email, $email_subject, $email_body);

        $msg = "Subject assigned & Email sent to $faculty_name ✔️";
    }
}

/* FETCH DATA */
$faculty = $conn->query("SELECT id, full_name FROM users WHERE role='faculty'");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Subjects</title>
<style>
    body { font-family: Arial; padding: 20px; }
    .box { border:1px solid #ccc; padding:15px; margin-bottom:20px; 
           border-radius:6px; background:#f7f7f7; }
    table { border-collapse: collapse; width: 70%; }
    th, td { padding: 10px; border: 1px solid #777; }
    th { background: #111; color: white; }
</style>

<script>
function filterSubjects() {
    let selectedCourse = document.getElementById("courseFilter").value;
    let options = document.querySelectorAll(".subject-option");

    options.forEach(opt => {
        opt.style.display = (selectedCourse === "" || opt.dataset.course === selectedCourse)
            ? "block"
            : "none";
    });
}
</script>

</head>
<body>

<h2>📘 Manage Subjects</h2>
<p style="color:green; font-weight:bold;"><?= $msg ?></p>

<!-- ADD SUBJECT -->
<div class="box">
<h3>Add Subject (Course-wise)</h3>

<form method="POST">
    <input name="subject_name" placeholder="Subject Name" required><br><br>

    <select name="course" required>
        <option value="">Select Course</option>
        <option>MCA</option>
        <option>MSC</option>
        <option>BCA</option>
        <option>BSC</option>
    </select><br><br>

    <button name="add_subject">Add Subject</button>
</form>
</div>

<!-- ASSIGN SUBJECT -->
<div class="box">
<h3>Allocate Subject to Faculty (Multiple Allowed)</h3>

<form method="POST">

<select name="faculty_id" required>
    <option value="">Select Faculty</option>
    <?php while ($f = $faculty->fetch_assoc()) { ?>
        <option value="<?= $f['id'] ?>"><?= $f['full_name'] ?></option>
    <?php } ?>
</select><br><br>

<select id="courseFilter" onchange="filterSubjects()">
    <option value="">Filter by Course</option>
    <option>MCA</option>
    <option>MSC</option>
    <option>BCA</option>
    <option>BSC</option>
</select><br><br>

<select name="subject_id" required>
<?php
$subList = $conn->query("SELECT * FROM subjects ORDER BY course, subject_name");
while ($s = $subList->fetch_assoc()) {
?>
    <option 
        class="subject-option"
        data-course="<?= $s['course'] ?>"
        value="<?= $s['id'] ?>"
    >
        <?= $s['subject_name'] ?> (<?= $s['course'] ?>)
    </option>
<?php } ?>
</select><br><br>

<button name="assign_subject">Assign Subject</button>
</form>
</div>

<!-- SUBJECT LIST -->
<div class="box">
<h3>All Subjects</h3>

<table>
<tr>
    <th>Subject</th>
    <th>Course</th>
    <th>Action</th>
</tr>

<?php
$subjects = $conn->query("SELECT * FROM subjects ORDER BY course, subject_name");
while ($row = $subjects->fetch_assoc()) {
?>
<tr>
    <td><?= $row['subject_name'] ?></td>
    <td><?= $row['course'] ?></td>
    <td>
        <a href="?delete_subject=<?= $row['id'] ?>" 
           onclick="return confirm('Delete this subject?')"
           style="color:red; font-weight:bold;">
           ❌ Delete
        </a>
    </td>
</tr>
<?php } ?>
</table>
</div>

<a href="dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
