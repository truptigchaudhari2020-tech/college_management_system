<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
require_once "../config/mailer.php"; // EMAIL SUPPORT
checkRole('admin');

$msg = "";
$error = "";

/* ADD FACULTY */
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['full_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $qualification = $_POST['qualification'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Multiple courses -> string
    $courses = implode(",", $_POST['courses']);

    // Check if email exists
    $check = $conn->query("SELECT id FROM users WHERE email='$email' OR username='$username'");
    if ($check->num_rows > 0) {
        $error = "❌ Email or Username already exists!";
    } else {
        $stmt = $conn->prepare("
            INSERT INTO users
            (full_name, mobile, email, username, password, qualification, courses, role)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'faculty')
        ");

        $stmt->bind_param(
            "sssssss",
            $name, $mobile, $email,
            $username, $password,
            $qualification, $courses
        );

        if ($stmt->execute()) {

            /* SEND WELCOME EMAIL */
            $subject = "Welcome to College Management System - Faculty Account Created";

            $body = "
            <h2>Welcome, $name!</h2>

            <p>Your faculty account has been successfully created.</p>

            <h3>Login Details</h3>
            <table border='1' cellpadding='8'>
                <tr><td><b>Username</b></td><td>$username</td></tr>
                <tr><td><b>Email</b></td><td>$email</td></tr>
                <tr><td><b>Qualification</b></td><td>$qualification</td></tr>
                <tr><td><b>Courses</b></td><td>$courses</td></tr>
            </table>

            <p>Your password has been securely saved (encrypted).</p>

            <p>Regards,<br>
            <b>College Management System</b></p>
            ";

            sendMail($email, $subject, $body);

            $msg = "Faculty registered successfully & Email Sent ✔️";
        } else {
            $error = "❌ Something went wrong!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Faculty</title>

<style>
    body { font-family: Arial; padding: 20px; }
    label { font-weight: bold; }
    .box { width: 50%; background: #f7f7f7; padding: 20px; border-radius: 8px; }
    input[type=text], input[type=password], input[type=email] {
        width: 100%; padding: 10px; margin: 5px 0;
        border-radius: 4px; border: 1px solid #aaa;
    }
    button {
        padding: 10px 15px; background: #333; color:#fff;
        border: none; border-radius: 4px; cursor:pointer;
    }
    button:hover { background:#000; }
</style>

</head>
<body>

<h2>👨‍🏫 Register Faculty</h2>

<?php if ($msg) { ?>
    <p style="color:green; font-weight:bold;"><?= $msg ?></p>
<?php } ?>

<?php if ($error) { ?>
    <p style="color:red; font-weight:bold;"><?= $error ?></p>
<?php } ?>

<div class="box">
<form method="POST">

<label>Full Name</label>
<input name="full_name" required>

<label>Mobile Number</label>
<input name="mobile" pattern="[0-9]{10}" required>

<label>Email</label>
<input type="email" name="email" required>

<label>Qualification</label>
<input name="qualification" placeholder="M.Sc, PhD, NET" required>

<label>Username</label>
<input name="username" required>

<label>Password</label>
<input type="password" name="password" required>

<label>Courses Teaching (Select Multiple)</label><br>
<input type="checkbox" name="courses[]" value="MCA"> MCA <br>
<input type="checkbox" name="courses[]" value="MSC"> MSC <br>
<input type="checkbox" name="courses[]" value="BCA"> BCA <br>
<input type="checkbox" name="courses[]" value="BSC"> BSC <br><br>

<button type="submit">Register Faculty</button>

</form>
</div>

<br>
<a href="dashboard.php">⬅ Back</a>

</body>
</html>
