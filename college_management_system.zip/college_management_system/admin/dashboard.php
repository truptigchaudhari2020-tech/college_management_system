<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
checkRole('admin');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            padding-bottom: 40px;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: fadeInDown 0.6s ease;
        }

        .header h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header p {
            font-size: 14px;
            opacity: 0.95;
            font-weight: 400;
        }

        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 16px;
            max-width: 1200px;
            margin: 0 auto;
            animation: fadeInUp 0.8s ease;
        }

        .card {
            background: white;
            border-radius: 20px;
            padding: 24px 16px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            position: relative;
            overflow: hidden;
            animation: scaleIn 0.5s ease backwards;
        }

        .card:nth-child(1) { animation-delay: 0.1s; }
        .card:nth-child(2) { animation-delay: 0.15s; }
        .card:nth-child(3) { animation-delay: 0.2s; }
        .card:nth-child(4) { animation-delay: 0.25s; }
        .card:nth-child(5) { animation-delay: 0.3s; }
        .card:nth-child(6) { animation-delay: 0.35s; }
        .card:nth-child(7) { animation-delay: 0.4s; }
        .card:nth-child(8) { animation-delay: 0.45s; }
        .card:nth-child(9) { animation-delay: 0.5s; }
        .card:nth-child(10) { animation-delay: 0.55s; }
        .card:nth-child(11) { animation-delay: 0.6s; }
        .card:nth-child(12) { animation-delay: 0.65s; }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(102,126,234,0.1) 0%, rgba(118,75,162,0.1) 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }

        .card:hover::before {
            opacity: 1;
        }

        .card:active {
            transform: translateY(-4px) scale(0.98);
        }

        .card a {
            text-decoration: none;
            color: #2d3748;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            position: relative;
            z-index: 1;
        }

        .icon {
            font-size: 40px;
            transition: transform 0.3s ease;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
        }

        .card:hover .icon {
            transform: scale(1.15) rotate(5deg);
        }

        .card-title {
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
        }

        /* Special styling for logout */
        .card.logout {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .card.logout a {
            color: white;
        }

        .card.logout:hover {
            background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%);
        }

        /* Animations */
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .header h2 {
                font-size: 24px;
            }

            .header p {
                font-size: 13px;
            }

            .dashboard {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }

            .card {
                padding: 20px 12px;
                border-radius: 16px;
            }

            .icon {
                font-size: 36px;
            }

            .card-title {
                font-size: 13px;
            }
        }

        @media (max-width: 400px) {
            .dashboard {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .card {
                padding: 24px 16px;
            }
        }

        /* Smooth page load */
        body {
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Add ripple effect on touch */
        .card::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255,255,255,0.5);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .card:active::after {
            width: 300px;
            height: 300px;
        }
    </style>
</head>
<body>

<div class="header">
    <h2>Welcome Admin 👨‍💼</h2>
    <p>College Management System – Admin Panel</p>
</div>

<div class="dashboard">

    <!-- Faculty -->
    <div class="card">
        <a href="add_faculty.php">
            <span class="icon">➕</span>
            <span class="card-title">Add Faculty</span>
        </a>
    </div>

    <div class="card">
        <a href="manage_faculty.php">
            <span class="icon">👨‍🏫</span>
            <span class="card-title">Manage Faculty</span>
        </a>
    </div>

    <div class="card">
        <a href="assign_course_subject.php">
            <span class="icon">📌</span>
            <span class="card-title">Assign Course & Subject</span>
        </a>
    </div>

    <!-- Students -->
    <div class="card">
        <a href="manage_students.php">
            <span class="icon">🎓</span>
            <span class="card-title">Manage Students</span>
        </a>
    </div>

    <!-- Academics -->
    <div class="card">
        <a href="manage_courses.php">
            <span class="icon">📘</span>
            <span class="card-title">Manage Courses</span>
        </a>
    </div>

    <div class="card">
        <a href="manage_subjects.php">
            <span class="icon">📗</span>
            <span class="card-title">Manage Subjects</span>
        </a>
    </div>

    <!-- Attendance -->
    <div class="card">
        <a href="manage_attendance.php">
            <span class="icon">🗓️</span>
            <span class="card-title">Manage Attendance</span>
        </a>
    </div>

    <!-- Fees -->
    <div class="card">
        <a href="manage_fees.php">
            <span class="icon">💰</span>
            <span class="card-title">Manage Fees</span>
        </a>
    </div>

    <!-- Library -->
    <div class="card">
        <a href="manage_library.php">
            <span class="icon">📚</span>
            <span class="card-title">Manage Library</span>
        </a>
    </div>

    <!-- Results -->
    <div class="card">
        <a href="manage_results.php">
            <span class="icon">📊</span>
            <span class="card-title">Manage Results</span>
        </a>
    </div>

    <!-- Notices -->
    <div class="card">
        <a href="notices.php">
            <span class="icon">📢</span>
            <span class="card-title">Notices</span>
        </a>
    </div>

    <!-- Logout -->
    <div class="card logout">
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span class="card-title">Logout</span>
        </a>
    </div>

</div>

</body>
</html>