<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
require_once "../config/mailer.php";  // <--- Email file added
checkRole('admin');

$msg = "";

/* STEP 1 — FETCH STUDENTS WHEN COURSE SELECTED */
$selected_course = $_GET['course'] ?? "";

/* Load students dynamically */
$students = null;
if ($selected_course) {
    $students = $conn->query("
        SELECT id, full_name, caste_category, email 
        FROM users 
        WHERE role='student' AND course='$selected_course'
    ");
}

/* STEP 2 — FETCH FEE STRUCTURE */
$fee_structure = $conn->query("SELECT * FROM fee_structure");

/* STEP 3 — SAVE PAYMENT */
if (isset($_POST['pay_fees'])) {

    $student_id = $_POST['student_id'];
    $paid_amount = $_POST['paid_amount'];
    $fee_type = $_POST['fee_type'];

    // Fetch student details
    $stu = $conn->query("
        SELECT full_name, email, caste_category, course
        FROM users 
        WHERE id=$student_id
    ")->fetch_assoc();

    $student_name = $stu['full_name'];
    $student_email = $stu['email'];
    $category = $stu['caste_category'];
    $st_course = $stu['course'];

    // Fetch total fees for the category
    $total_fee = $conn->query("
        SELECT total_fee FROM fee_structure 
        WHERE caste_category='$category'
    ")->fetch_assoc()['total_fee'];

    // Calculate already paid
    $paid_sum = $conn->query("
        SELECT SUM(amount) AS total_paid 
        FROM fees 
        WHERE student_id=$student_id
    ")->fetch_assoc()['total_paid'];

    if (!$paid_sum) $paid_sum = 0;

    $remaining = $total_fee - ($paid_sum + $paid_amount);

    // Insert fee payment
    $stmt = $conn->prepare("
        INSERT INTO fees (student_id, fee_type, amount, payment_date, status)
        VALUES (?, ?, ?, CURDATE(), 'Paid')
    ");
    $stmt->bind_param("isd", $student_id, $fee_type, $paid_amount);
    $stmt->execute();

    // -----------------------------
    // SEND EMAIL TO STUDENT
    // -----------------------------

    $subject = "Fee Payment Confirmation - $student_name";

    $body = "
    <h2>Fee Payment Confirmation</h2>
    <p>Dear <b>$student_name</b>,</p>

    <p>Your fee payment has been successfully recorded.</p>

    <h3>Payment Details:</h3>
    <table border='1' cellpadding='8'>
        <tr><td><b>Student Name</b></td><td>$student_name</td></tr>
        <tr><td><b>Course</b></td><td>$st_course</td></tr>
        <tr><td><b>Category</b></td><td>$category</td></tr>
        <tr><td><b>Total Fee</b></td><td>₹$total_fee</td></tr>
        <tr><td><b>Paid Now</b></td><td>₹$paid_amount</td></tr>
        <tr><td><b>Total Paid Till Now</b></td><td>₹" . ($paid_sum + $paid_amount) . "</td></tr>
        <tr><td><b>Remaining Fee</b></td><td>₹$remaining</td></tr>
        <tr><td><b>Payment Date</b></td><td>" . date('Y-m-d') . "</td></tr>
    </table>

    <p>Thank you,<br>
    <b>College Management System</b>
    </p>
    ";

    sendMail($student_email, $subject, $body);

    $msg = "Fees Updated Successfully! Email Sent ✔️ Remaining: ₹$remaining";
}

/* FETCH ALL PAYMENTS */
$payments = $conn->query("
    SELECT f.payment_date, f.fee_type, f.amount, u.full_name, u.course
    FROM fees f
    JOIN users u ON u.id=f.student_id
    ORDER BY f.payment_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Fees</title>
<style>
    .box { border:1px solid #ccc; padding:15px; margin:15px; }
</style>
</head>
<body>

<h2>💰 Manage Student Fees</h2>
<p style="color:green;"><?= $msg ?></p>

<!-- SELECT COURSE -->
<div class="box">
<form method="GET">
    <label>Select Course:</label>
    <select name="course" required>
        <option value="">Choose</option>
        <option <?= $selected_course=='MCA'?'selected':'' ?>>MCA</option>
        <option <?= $selected_course=='MSC'?'selected':'' ?>>MSC</option>
        <option <?= $selected_course=='BCA'?'selected':'' ?>>BCA</option>
        <option <?= $selected_course=='BSC'?'selected':'' ?>>BSC</option>
    </select>
    <button>Search Students</button>
</form>
</div>

<!-- SELECT STUDENT + PAY FEES -->
<?php if ($students) { ?>
<div class="box">
<h3>Set Fees for <?= $selected_course ?> Students</h3>

<form method="POST">
<select name="student_id" required>
    <option value="">Select Student</option>

    <?php while ($s = $students->fetch_assoc()) { ?>
        <?php
        $cat = $s['caste_category'];
        $fee_row = $conn->query("SELECT total_fee FROM fee_structure WHERE caste_category='$cat'")->fetch_assoc();
        $total_fee = $fee_row['total_fee'];

        $paid_sum = $conn->query("SELECT SUM(amount) AS paid FROM fees WHERE student_id=".$s['id'])->fetch_assoc()['paid'];
        if (!$paid_sum) $paid_sum = 0;
        $remaining_fee = $total_fee - $paid_sum;
        ?>
        <option value="<?= $s['id'] ?>">
            <?= $s['full_name'] ?> (<?= $cat ?> - Pending ₹<?= $remaining_fee ?>)
        </option>
    <?php } ?>
</select>
<br><br>

<select name="fee_type">
    <option>Admission</option>
    <option>Exam</option>
    <option>Other</option>
</select><br><br>

<input type="number" name="paid_amount" placeholder="Enter Paid Amount" required><br><br>

<button name="pay_fees">Submit Payment</button>
</form>
</div>
<?php } ?>


<!-- PAYMENT HISTORY -->
<div class="box">
<h3>📄 All Fee Payments</h3>

<table border="1" cellpadding="8">
<tr>
    <th>Date</th>
    <th>Student</th>
    <th>Course</th>
    <th>Fee Type</th>
    <th>Amount</th>
</tr>

<?php while ($row = $payments->fetch_assoc()) { ?>
<tr>
    <td><?= $row['payment_date'] ?></td>
    <td><?= $row['full_name'] ?></td>
    <td><?= $row['course'] ?></td>
    <td><?= $row['fee_type'] ?></td>
    <td>₹<?= $row['amount'] ?></td>
</tr>
<?php } ?>

</table>
</div>

<a href="dashboard.php">⬅ Back</a>

</body>
</html>
