<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$msg = "";
$msgType = "";

/* DELETE FACULTY */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Remove faculty subjects first
    $conn->query("DELETE FROM faculty_subjects WHERE faculty_id=$id");

    // Delete faculty
    $conn->query("DELETE FROM users WHERE id=$id AND role='faculty'");

    $msg = "Faculty member deleted successfully!";
    $msgType = "success";
    header("Location: manage_faculty.php?msg=" . urlencode($msg) . "&type=" . $msgType);
    exit;
}

// Get message from URL if exists
if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    $msgType = $_GET['type'] ?? 'info';
}

// Filters
$searchQuery = $_GET['search'] ?? '';
$courseFilter = $_GET['course'] ?? '';

/* FETCH FACULTY + SUBJECTS */
$sql = "
    SELECT 
        u.id,
        u.full_name,
        u.email,
        u.mobile,
        u.qualification,
        u.courses,
        GROUP_CONCAT(DISTINCT CONCAT(fs.course, ': ', fs.subject) SEPARATOR ' | ') AS subjects
    FROM users u
    LEFT JOIN faculty_subjects fs ON u.id = fs.faculty_id
    WHERE u.role='faculty'
";

if ($searchQuery != '') {
    $sql .= " AND (u.full_name LIKE '%$searchQuery%' OR u.email LIKE '%$searchQuery%' OR u.qualification LIKE '%$searchQuery%')";
}

$sql .= " GROUP BY u.id ORDER BY u.full_name";

$result = $conn->query($sql);

// Get statistics
$totalFaculty = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='faculty'")->fetch_assoc()['count'];
$assignedFaculty = $conn->query("SELECT COUNT(DISTINCT faculty_id) as count FROM faculty_subjects")->fetch_assoc()['count'];
$unassignedFaculty = $totalFaculty - $assignedFaculty;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Faculty</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            animation: fadeIn 0.5s ease;
        }

        .container {
            max-width: 1300px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: slideDown 0.6s ease;
        }

        .header h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header .icon {
            font-size: 48px;
            margin-bottom: 10px;
            display: inline-block;
        }

        /* Alert Messages */
        .alert {
            background: white;
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: slideDown 0.5s ease;
        }

        .alert.success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
        }

        .alert-icon {
            font-size: 24px;
        }

        /* Statistics Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
            animation: slideUp 0.7s ease;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 13px;
            color: #718096;
            font-weight: 500;
        }

        .stat-card.total { border-left: 4px solid #667eea; }
        .stat-card.assigned { border-left: 4px solid #48bb78; }
        .stat-card.unassigned { border-left: 4px solid #f6ad55; }

        /* Info Card */
        .info-card {
            background: white;
            border-radius: 16px;
            padding: 20px 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 24px;
            animation: scaleIn 0.6s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid #4299e1;
        }

        .info-icon {
            font-size: 24px;
        }

        .info-text {
            color: #4a5568;
            font-size: 14px;
            line-height: 1.6;
        }

        /* Filter Section */
        .filter-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 24px;
            animation: scaleIn 0.7s ease;
        }

        .filter-title {
            font-size: 18px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 16px;
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 6px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: #f8fafc;
        }

        input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #2d3748;
        }

        .btn-secondary:hover {
            background: #cbd5e0;
        }

        .btn-export {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
        }

        .btn-add {
            background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(66, 153, 225, 0.3);
        }

        /* Table Card */
        .table-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
            animation: slideUp 0.8s ease;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f7fafc;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #2d3748;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 14px 12px;
            color: #4a5568;
            font-size: 14px;
            border-bottom: 1px solid #f1f5f9;
        }

        tr:hover {
            background: #f8fafc;
        }

        .subject-list {
            color: #4299e1;
            font-size: 13px;
            line-height: 1.6;
        }

        .no-subjects {
            color: #a0aec0;
            font-style: italic;
        }

        .btn-delete {
            padding: 6px 14px;
            background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(245, 101, 101, 0.4);
        }

        /* Mobile Cards */
        .mobile-cards {
            display: none;
        }

        .faculty-card-mobile {
            background: white;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }

        .card-header-mobile {
            margin-bottom: 12px;
        }

        .faculty-name {
            font-weight: 700;
            color: #2d3748;
            font-size: 16px;
            margin-bottom: 4px;
        }

        .faculty-email {
            color: #718096;
            font-size: 13px;
        }

        .card-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
            gap: 12px;
        }

        .card-label {
            color: #718096;
            font-weight: 500;
            min-width: 100px;
        }

        .card-value {
            color: #2d3748;
            font-weight: 600;
            text-align: right;
            flex: 1;
        }

        .card-actions {
            margin-top: 12px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 24px;
            padding: 12px 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-4px);
        }

        .no-records {
            text-align: center;
            padding: 40px;
            color: #718096;
            font-size: 16px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .header h2 {
                font-size: 24px;
            }

            .stats-container {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }

            .stat-card {
                padding: 16px;
            }

            .stat-value {
                font-size: 24px;
            }

            .filter-card {
                padding: 20px;
            }

            .filter-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .filter-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }

            .table-responsive {
                display: none;
            }

            .mobile-cards {
                display: block;
            }

            .info-card {
                flex-direction: column;
                text-align: center;
            }
        }

        @media (max-width: 400px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="icon">👨‍🏫</div>
        <h2>Faculty Management</h2>
    </div>

    <!-- Alert Message -->
    <?php if ($msg): ?>
    <div class="alert <?= $msgType ?>">
        <span class="alert-icon">✓</span>
        <span><?= htmlspecialchars($msg) ?></span>
    </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-container">
        <div class="stat-card total">
            <div class="stat-icon">👥</div>
            <div class="stat-value"><?= $totalFaculty ?></div>
            <div class="stat-label">Total Faculty</div>
        </div>
        <div class="stat-card assigned">
            <div class="stat-icon">✅</div>
            <div class="stat-value"><?= $assignedFaculty ?></div>
            <div class="stat-label">Assigned</div>
        </div>
        <div class="stat-card unassigned">
            <div class="stat-icon">⏳</div>
            <div class="stat-value"><?= $unassignedFaculty ?></div>
            <div class="stat-label">Unassigned</div>
        </div>
    </div>

    <!-- Info Card -->
    <div class="info-card">
        <span class="info-icon">ℹ️</span>
        <p class="info-text">
            <strong>Faculty Management:</strong> View all registered faculty members along with their assigned subjects. 
            You can search, filter, and manage faculty assignments from this page.
        </p>
    </div>

    <!-- Filter Section -->
    <div class="filter-card">
        <div class="filter-title">🔍 Search Faculty</div>
        <form method="GET">
            <div class="filter-grid">
                <div class="form-group">
                    <label>Search by Name, Email or Qualification</label>
                    <input type="text" name="search" placeholder="Search faculty members..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
            </div>
            <div class="filter-actions">
                <button type="submit" class="btn btn-primary">🔍 Search</button>
                <a href="manage_faculty.php" class="btn btn-secondary">🔄 Reset</a>
                <button type="button" onclick="exportToCSV()" class="btn btn-export">📥 Export CSV</button>
                <a href="add_faculty.php" class="btn btn-add">➕ Add New Faculty</a>
            </div>
        </form>
    </div>

    <!-- Table Card -->
    <div class="table-card">
        <!-- Desktop Table View -->
        <div class="table-responsive">
            <?php if ($result->num_rows > 0): ?>
            <table id="facultyTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Qualification</th>
                        <th>Courses</th>
                        <th>Assigned Subjects</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['mobile']) ?></td>
                        <td><?= htmlspecialchars($row['qualification'] ?: "N/A") ?></td>
                        <td><?= htmlspecialchars($row['courses'] ?: "N/A") ?></td>
                        <td class="subject-list">
                            <?php if ($row['subjects']): ?>
                                <?= htmlspecialchars($row['subjects']) ?>
                            <?php else: ?>
                                <span class="no-subjects">No subjects assigned</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="?delete=<?= $row['id'] ?>" 
                               class="btn-delete"
                               onclick="return confirm('Are you sure you want to delete this faculty? This will also remove all assigned subjects.');">
                                🗑️ Delete
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-records">📭 No faculty members found</div>
            <?php endif; ?>
        </div>

        <!-- Mobile Card View -->
        <div class="mobile-cards">
            <?php 
            $result->data_seek(0);
            if ($result->num_rows > 0):
                while ($row = $result->fetch_assoc()): 
            ?>
            <div class="faculty-card-mobile">
                <div class="card-header-mobile">
                    <div class="faculty-name"><?= htmlspecialchars($row['full_name']) ?></div>
                    <div class="faculty-email"><?= htmlspecialchars($row['email']) ?></div>
                </div>
                <div class="card-row">
                    <span class="card-label">Mobile:</span>
                    <span class="card-value"><?= htmlspecialchars($row['mobile']) ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Qualification:</span>
                    <span class="card-value"><?= htmlspecialchars($row['qualification'] ?: "N/A") ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Courses:</span>
                    <span class="card-value"><?= htmlspecialchars($row['courses'] ?: "N/A") ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Subjects:</span>
                    <span class="card-value subject-list">
                        <?php if ($row['subjects']): ?>
                            <?= htmlspecialchars($row['subjects']) ?>
                        <?php else: ?>
                            <span class="no-subjects">None</span>
                        <?php endif; ?>
                    </span>
                </div>
                <div class="card-actions">
                    <a href="?delete=<?= $row['id'] ?>" 
                       class="btn-delete"
                       style="width: 100%; justify-content: center;"
                       onclick="return confirm('Are you sure you want to delete this faculty?');">
                        🗑️ Delete Faculty
                    </a>
                </div>
            </div>
            <?php 
                endwhile;
            else:
            ?>
            <div class="no-records">📭 No faculty members found</div>
            <?php endif; ?>
        </div>
    </div>

    <center>
        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </center>
</div>

<script>
function exportToCSV() {
    let csv = 'Name,Email,Mobile,Qualification,Courses,Assigned Subjects\n';
    const table = document.getElementById('facultyTable');
    
    if (!table) {
        alert('No data to export');
        return;
    }
    
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        const rowData = [];
        
        for (let i = 0; i < cols.length - 1; i++) {
            let text = cols[i].textContent.trim();
            text = text.replace(/\s+/g, ' ');
            rowData.push('"' + text + '"');
        }
        
        csv += rowData.join(',') + '\n';
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'faculty_list_' + new Date().toISOString().split('T')[0] + '.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}
</script>

</body>
</html>