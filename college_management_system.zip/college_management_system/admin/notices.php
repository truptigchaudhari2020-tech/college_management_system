<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
require_once "../config/mailer.php";   // EMAIL SUPPORT
checkRole('admin');

$msg = "";

/* DELETE NOTICE */
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM notices WHERE id = $id");
    header("Location: notices.php");
    exit;
}

/* ADD NOTICE */
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $title = $_POST['title'];
    $message = $_POST['message'];

    // Insert notice into DB
    $stmt = $conn->prepare("INSERT INTO notices (title, message) VALUES (?,?)");
    $stmt->bind_param("ss", $title, $message);
    $stmt->execute();

    /* SEND EMAIL TO ALL STUDENTS */
    $students = $conn->query("SELECT full_name, email FROM users WHERE role='student'");

    while ($s = $students->fetch_assoc()) {

        $student_name = $s['full_name'];
        $email = $s['email'];

        $subject = "New College Notice: $title";

        $body = "
        <h2>New College Notice</h2>
        <p>Hello <b>$student_name</b>,</p>

        <p>A new notice has been published by the college administration.</p>

        <h3>$title</h3>
        <p>$message</p>

        <p>Regards,<br>
        <b>College Management System</b>
        </p>
        ";

        sendMail($email, $subject, $body);
    }

    $msg = "Notice Published & Email Sent to All Students ✔️";
}

$result = $conn->query("SELECT * FROM notices ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Notices</title>
    <style>
        .notice-box {
            border: 1px solid #ccc;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 6px;
            background: #f9f9f9;
        }
        .delete-btn {
            color: red;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>📢 Publish Notice</h2>

<form method="POST">
    <input name="title" placeholder="Notice Title" required><br><br>
    <textarea name="message" placeholder="Notice Message" required></textarea><br><br>
    <button type="submit">Publish</button>
</form>

<p style="color:green;"><?= $msg ?></p>

<hr>

<h3>All Notices</h3>

<?php if ($result->num_rows > 0) { ?>
    <?php while ($row = $result->fetch_assoc()) { ?>
        <div class="notice-box">
            <h4><?= htmlspecialchars($row['title']) ?></h4>
            <p><?= nl2br(htmlspecialchars($row['message'])) ?></p>
            <small>Posted on: <?= $row['created_at'] ?></small>
            <br><br>
            <a 
                href="?delete=<?= $row['id'] ?>" 
                class="delete-btn"
                onclick="return confirm('Are you sure you want to delete this notice?');"
            >
                ❌ Delete
            </a>
        </div>
    <?php } ?>
<?php } else { ?>
    <p>No notices found.</p>
<?php } ?>

<a href="dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
