<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$msg = "";
$msgType = "";

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id=$id AND role='student'");
    $msg = "Student deleted successfully!";
    $msgType = "success";
    header("Location: manage_students.php?msg=" . urlencode($msg) . "&type=" . $msgType);
    exit;
}

// Get message from URL if exists
if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    $msgType = $_GET['type'] ?? 'info';
}

// Filters
$courseFilter = $_GET['course'] ?? '';
$casteFilter = $_GET['caste'] ?? '';
$searchQuery = $_GET['search'] ?? '';

// Build query
$sql = "SELECT * FROM users WHERE role='student'";

if ($courseFilter != '') {
    $sql .= " AND course='$courseFilter'";
}

if ($casteFilter != '') {
    $sql .= " AND caste_category='$casteFilter'";
}

if ($searchQuery != '') {
    $sql .= " AND (full_name LIKE '%$searchQuery%' OR email LIKE '%$searchQuery%' OR username LIKE '%$searchQuery%')";
}

$sql .= " ORDER BY full_name ASC";

$result = $conn->query($sql);

// Get statistics
$statsQuery = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN course='MCA' THEN 1 ELSE 0 END) as mca,
    SUM(CASE WHEN course='MSC' THEN 1 ELSE 0 END) as msc,
    SUM(CASE WHEN course='BCA' THEN 1 ELSE 0 END) as bca,
    SUM(CASE WHEN course='BSC' THEN 1 ELSE 0 END) as bsc
FROM users WHERE role='student'";

$statsResult = $conn->query($statsQuery);
$stats = $statsResult->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            animation: fadeIn 0.5s ease;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: slideDown 0.6s ease;
        }

        .header h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header .icon {
            font-size: 48px;
            margin-bottom: 10px;
            display: inline-block;
        }

        /* Statistics Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
            animation: slideUp 0.7s ease;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 13px;
            color: #718096;
            font-weight: 500;
        }

        .stat-card.total { border-left: 4px solid #667eea; }
        .stat-card.mca { border-left: 4px solid #48bb78; }
        .stat-card.msc { border-left: 4px solid #ed8936; }
        .stat-card.bca { border-left: 4px solid #4299e1; }
        .stat-card.bsc { border-left: 4px solid #9f7aea; }

        /* Alert Messages */
        .alert {
            background: white;
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: slideDown 0.5s ease;
        }

        .alert.success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
        }

        .alert.error {
            background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
            color: white;
        }

        .alert-icon {
            font-size: 24px;
        }

        /* Filter Section */
        .filter-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 24px;
            animation: scaleIn 0.6s ease;
        }

        .filter-title {
            font-size: 18px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 6px;
        }

        select, input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: #f8fafc;
        }

        select:focus, input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #2d3748;
        }

        .btn-secondary:hover {
            background: #cbd5e0;
        }

        .btn-export {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
        }

        /* Table Card */
        .table-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
            animation: slideUp 0.8s ease;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .table-title {
            font-size: 20px;
            font-weight: 700;
            color: #2d3748;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f7fafc;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #2d3748;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 14px 12px;
            color: #4a5568;
            font-size: 14px;
            border-bottom: 1px solid #f1f5f9;
        }

        tr:hover {
            background: #f8fafc;
        }

        .course-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-mca { background: #c6f6d5; color: #22543d; }
        .badge-msc { background: #feebc8; color: #7c2d12; }
        .badge-bca { background: #bee3f8; color: #1e4e8c; }
        .badge-bsc { background: #e9d8fd; color: #44337a; }

        .caste-badge {
            display: inline-block;
            padding: 4px 10px;
            background: #e6fffa;
            color: #234e52;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-delete {
            padding: 6px 14px;
            background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(245, 101, 101, 0.4);
        }

        .btn-view {
            padding: 6px 14px;
            background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(66, 153, 225, 0.4);
        }

        /* Mobile Cards */
        .mobile-cards {
            display: none;
        }

        .student-card-mobile {
            background: white;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }

        .card-header-mobile {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .student-name {
            font-weight: 700;
            color: #2d3748;
            font-size: 16px;
        }

        .card-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
        }

        .card-label {
            color: #718096;
            font-weight: 500;
        }

        .card-value {
            color: #2d3748;
            font-weight: 600;
        }

        .card-actions {
            display: flex;
            gap: 8px;
            margin-top: 12px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 24px;
            padding: 12px 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-4px);
        }

        .no-records {
            text-align: center;
            padding: 40px;
            color: #718096;
            font-size: 16px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .header h2 {
                font-size: 24px;
            }

            .stats-container {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }

            .stat-card {
                padding: 16px;
            }

            .stat-value {
                font-size: 24px;
            }

            .filter-card {
                padding: 20px;
            }

            .filter-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .filter-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }

            .table-responsive {
                display: none;
            }

            .mobile-cards {
                display: block;
            }

            .table-header {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="icon">🎓</div>
        <h2>Student Management</h2>
    </div>

    <!-- Alert Message -->
    <?php if ($msg): ?>
    <div class="alert <?= $msgType ?>">
        <span class="alert-icon"><?= $msgType == 'success' ? '✓' : '⚠' ?></span>
        <span><?= htmlspecialchars($msg) ?></span>
    </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-container">
        <div class="stat-card total">
            <div class="stat-icon">👥</div>
            <div class="stat-value"><?= $stats['total'] ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card mca">
            <div class="stat-icon">💻</div>
            <div class="stat-value"><?= $stats['mca'] ?></div>
            <div class="stat-label">MCA</div>
        </div>
        <div class="stat-card msc">
            <div class="stat-icon">🔬</div>
            <div class="stat-value"><?= $stats['msc'] ?></div>
            <div class="stat-label">MSC</div>
        </div>
        <div class="stat-card bca">
            <div class="stat-icon">🖥️</div>
            <div class="stat-value"><?= $stats['bca'] ?></div>
            <div class="stat-label">BCA</div>
        </div>
        <div class="stat-card bsc">
            <div class="stat-icon">🧪</div>
            <div class="stat-value"><?= $stats['bsc'] ?></div>
            <div class="stat-label">BSC</div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-card">
        <div class="filter-title">🔍 Search & Filter</div>
        <form method="GET">
            <div class="filter-grid">
                <div class="form-group">
                    <label>Search Student</label>
                    <input type="text" name="search" placeholder="Name, Email, or Username..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                <div class="form-group">
                    <label>Course</label>
                    <select name="course">
                        <option value="">All Courses</option>
                        <option <?= $courseFilter == 'MCA' ? 'selected' : '' ?>>MCA</option>
                        <option <?= $courseFilter == 'MSC' ? 'selected' : '' ?>>MSC</option>
                        <option <?= $courseFilter == 'BCA' ? 'selected' : '' ?>>BCA</option>
                        <option <?= $courseFilter == 'BSC' ? 'selected' : '' ?>>BSC</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Caste Category</label>
                    <select name="caste">
                        <option value="">All Categories</option>
                        <option <?= $casteFilter == 'Open' ? 'selected' : '' ?>>Open</option>
                        <option <?= $casteFilter == 'OBC' ? 'selected' : '' ?>>OBC</option>
                        <option <?= $casteFilter == 'SC' ? 'selected' : '' ?>>SC</option>
                        <option <?= $casteFilter == 'ST' ? 'selected' : '' ?>>ST</option>
                        <option <?= $casteFilter == 'NT' ? 'selected' : '' ?>>NT</option>
                        <option <?= $casteFilter == 'VJNT' ? 'selected' : '' ?>>VJNT</option>
                    </select>
                </div>
            </div>
            <div class="filter-actions">
                <button type="submit" class="btn btn-primary">🔍 Apply Filters</button>
                <a href="manage_students.php" class="btn btn-secondary">🔄 Reset</a>
                <button type="button" onclick="exportToCSV()" class="btn btn-export">📥 Export CSV</button>
            </div>
        </form>
    </div>

    <!-- Table Card -->
    <div class="table-card">
        <div class="table-header">
            <div class="table-title">📋 Student List</div>
        </div>

        <!-- Desktop Table View -->
        <div class="table-responsive">
            <?php if ($result->num_rows > 0): ?>
            <table id="studentTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Course</th>
                        <th>Caste Category</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['mobile']) ?></td>
                        <td>
                            <span class="course-badge badge-<?= strtolower($row['course']) ?>">
                                <?= $row['course'] ?>
                            </span>
                        </td>
                        <td>
                            <span class="caste-badge"><?= $row['caste_category'] ?></span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="?delete=<?= $row['id'] ?>" 
                                   class="btn-delete" 
                                   onclick="return confirm('Are you sure you want to delete this student?')">
                                    🗑️ Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-records">📭 No students found</div>
            <?php endif; ?>
        </div>

        <!-- Mobile Card View -->
        <div class="mobile-cards">
            <?php 
            $result->data_seek(0);
            if ($result->num_rows > 0):
                while ($row = $result->fetch_assoc()): 
            ?>
            <div class="student-card-mobile">
                <div class="card-header-mobile">
                    <div class="student-name"><?= htmlspecialchars($row['full_name']) ?></div>
                    <span class="course-badge badge-<?= strtolower($row['course']) ?>">
                        <?= $row['course'] ?>
                    </span>
                </div>
                <div class="card-row">
                    <span class="card-label">Email:</span>
                    <span class="card-value"><?= htmlspecialchars($row['email']) ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Mobile:</span>
                    <span class="card-value"><?= htmlspecialchars($row['mobile']) ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Category:</span>
                    <span class="card-value"><?= $row['caste_category'] ?></span>
                </div>
                <div class="card-actions">
                    <a href="?delete=<?= $row['id'] ?>" 
                       class="btn-delete" 
                       onclick="return confirm('Are you sure you want to delete this student?')">
                        🗑️ Delete
                    </a>
                </div>
            </div>
            <?php 
                endwhile;
            else:
            ?>
            <div class="no-records">📭 No students found</div>
            <?php endif; ?>
        </div>
    </div>

    <center>
        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </center>
</div>

<script>
function exportToCSV() {
    let csv = 'Name,Email,Mobile,Course,Caste Category\n';
    const table = document.getElementById('studentTable');
    
    if (!table) {
        alert('No data to export');
        return;
    }
    
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        const rowData = [];
        
        for (let i = 0; i < cols.length - 1; i++) {
            let text = cols[i].textContent.trim();
            text = text.replace(/\s+/g, ' ');
            rowData.push('"' + text + '"');
        }
        
        csv += rowData.join(',') + '\n';
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'students_list_' + new Date().toISOString().split('T')[0] + '.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}
</script>

</body>
</html>