<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

// Filters
$courseFilter = $_GET['course'] ?? '';
$searchQuery = $_GET['search'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$statusFilter = $_GET['status'] ?? '';

// Build SQL query
$sql = "
SELECT 
    a.attendance_date,
    a.status,
    a.subject,
    s.full_name AS student_name,
    f.full_name AS faculty_name,
    a.course
FROM attendance a
JOIN users s ON a.student_id = s.id
JOIN users f ON a.faculty_id = f.id
WHERE 1=1
";

if ($courseFilter != '') {
    $sql .= " AND a.course='$courseFilter'";
}

if ($searchQuery != '') {
    $sql .= " AND (s.full_name LIKE '%$searchQuery%' OR f.full_name LIKE '%$searchQuery%' OR a.subject LIKE '%$searchQuery%')";
}

if ($dateFrom != '') {
    $sql .= " AND a.attendance_date >= '$dateFrom'";
}

if ($dateTo != '') {
    $sql .= " AND a.attendance_date <= '$dateTo'";
}

if ($statusFilter != '') {
    $sql .= " AND a.status = '$statusFilter'";
}

$sql .= " ORDER BY a.attendance_date DESC";

$result = $conn->query($sql);

// Calculate statistics
$statsQuery = "
SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) as present,
    SUM(CASE WHEN status='Absent' THEN 1 ELSE 0 END) as absent
FROM attendance a
WHERE 1=1
";

if ($courseFilter != '') {
    $statsQuery .= " AND a.course='$courseFilter'";
}

if ($dateFrom != '') {
    $statsQuery .= " AND a.attendance_date >= '$dateFrom'";
}

if ($dateTo != '') {
    $statsQuery .= " AND a.attendance_date <= '$dateTo'";
}

$statsResult = $conn->query($statsQuery);
$stats = $statsResult->fetch_assoc();
$attendancePercent = $stats['total'] > 0 ? round(($stats['present'] / $stats['total']) * 100, 1) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Attendance</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            animation: fadeIn 0.5s ease;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: slideDown 0.6s ease;
        }

        .header h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header .icon {
            font-size: 48px;
            margin-bottom: 10px;
            display: inline-block;
        }

        /* Statistics Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
            animation: slideUp 0.7s ease;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 14px;
            color: #718096;
            font-weight: 500;
        }

        .stat-card.success { border-left: 4px solid #48bb78; }
        .stat-card.danger { border-left: 4px solid #f56565; }
        .stat-card.info { border-left: 4px solid #4299e1; }

        /* Filter Section */
        .filter-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 24px;
            animation: scaleIn 0.6s ease;
        }

        .filter-title {
            font-size: 18px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 6px;
        }

        select, input[type="text"], input[type="date"] {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: #f8fafc;
        }

        select:focus, input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #2d3748;
        }

        .btn-secondary:hover {
            background: #cbd5e0;
        }

        .btn-export {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
        }

        .btn-export:hover {
            transform: translateY(-2px);
        }

        /* Table Styles */
        .table-card {
            background: white;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
            animation: slideUp 0.8s ease;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f7fafc;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #2d3748;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 14px 12px;
            color: #4a5568;
            font-size: 14px;
            border-bottom: 1px solid #f1f5f9;
        }

        tr:hover {
            background: #f8fafc;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-present {
            background: #c6f6d5;
            color: #22543d;
        }

        .status-absent {
            background: #fed7d7;
            color: #742a2a;
        }

        .course-badge {
            display: inline-block;
            padding: 4px 10px;
            background: #e6fffa;
            color: #234e52;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
        }

        /* Mobile Cards (shown on small screens) */
        .mobile-cards {
            display: none;
        }

        .attendance-card-mobile {
            background: white;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }

        .card-header-mobile {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .card-date {
            font-weight: 700;
            color: #2d3748;
        }

        .card-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
        }

        .card-label {
            color: #718096;
            font-weight: 500;
        }

        .card-value {
            color: #2d3748;
            font-weight: 600;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 24px;
            padding: 12px 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-4px);
        }

        .no-records {
            text-align: center;
            padding: 40px;
            color: #718096;
            font-size: 16px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .header h2 {
                font-size: 24px;
            }

            .stats-container {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }

            .stat-card {
                padding: 16px;
            }

            .stat-value {
                font-size: 24px;
            }

            .filter-card {
                padding: 20px;
            }

            .filter-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .filter-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }

            .table-responsive {
                display: none;
            }

            .mobile-cards {
                display: block;
            }
        }

        @media (max-width: 400px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="icon">🗓️</div>
        <h2>Attendance Management</h2>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-container">
        <div class="stat-card info">
            <div class="stat-icon">📊</div>
            <div class="stat-value"><?= $stats['total'] ?></div>
            <div class="stat-label">Total Records</div>
        </div>
        <div class="stat-card success">
            <div class="stat-icon">✅</div>
            <div class="stat-value"><?= $stats['present'] ?></div>
            <div class="stat-label">Present</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-icon">❌</div>
            <div class="stat-value"><?= $stats['absent'] ?></div>
            <div class="stat-label">Absent</div>
        </div>
        <div class="stat-card info">
            <div class="stat-icon">📈</div>
            <div class="stat-value"><?= $attendancePercent ?>%</div>
            <div class="stat-label">Attendance Rate</div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-card">
        <div class="filter-title">🔍 Filters & Search</div>
        <form method="GET">
            <div class="filter-grid">
                <div class="form-group">
                    <label>Search</label>
                    <input type="text" name="search" placeholder="Student, Faculty, or Subject..." value="<?= htmlspecialchars($searchQuery) ?>">
                </div>
                <div class="form-group">
                    <label>Course</label>
                    <select name="course">
                        <option value="">All Courses</option>
                        <option <?= $courseFilter == 'MCA' ? 'selected' : '' ?>>MCA</option>
                        <option <?= $courseFilter == 'MSC' ? 'selected' : '' ?>>MSC</option>
                        <option <?= $courseFilter == 'BCA' ? 'selected' : '' ?>>BCA</option>
                        <option <?= $courseFilter == 'BSC' ? 'selected' : '' ?>>BSC</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="">All Status</option>
                        <option <?= $statusFilter == 'Present' ? 'selected' : '' ?>>Present</option>
                        <option <?= $statusFilter == 'Absent' ? 'selected' : '' ?>>Absent</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>From Date</label>
                    <input type="date" name="date_from" value="<?= $dateFrom ?>">
                </div>
                <div class="form-group">
                    <label>To Date</label>
                    <input type="date" name="date_to" value="<?= $dateTo ?>">
                </div>
            </div>
            <div class="filter-actions">
                <button type="submit" class="btn btn-primary">🔍 Apply Filters</button>
                <a href="manage_attendance.php" class="btn btn-secondary">🔄 Reset</a>
                <button type="button" onclick="exportToCSV()" class="btn btn-export">📥 Export CSV</button>
            </div>
        </form>
    </div>

    <!-- Table View (Desktop) -->
    <div class="table-card">
        <div class="table-responsive">
            <?php if ($result->num_rows > 0): ?>
            <table id="attendanceTable">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Faculty</th>
                        <th>Course</th>
                        <th>Subject</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($row['attendance_date'])) ?></td>
                        <td><?= htmlspecialchars($row['student_name']) ?></td>
                        <td><?= htmlspecialchars($row['faculty_name']) ?></td>
                        <td><span class="course-badge"><?= $row['course'] ?></span></td>
                        <td><?= htmlspecialchars($row['subject']) ?></td>
                        <td>
                            <span class="status-badge status-<?= strtolower($row['status']) ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-records">📭 No attendance records found</div>
            <?php endif; ?>
        </div>

        <!-- Mobile Card View -->
        <div class="mobile-cards">
            <?php 
            $result->data_seek(0); // Reset result pointer
            if ($result->num_rows > 0):
                while ($row = $result->fetch_assoc()): 
            ?>
            <div class="attendance-card-mobile">
                <div class="card-header-mobile">
                    <span class="card-date"><?= date('d M Y', strtotime($row['attendance_date'])) ?></span>
                    <span class="status-badge status-<?= strtolower($row['status']) ?>">
                        <?= $row['status'] ?>
                    </span>
                </div>
                <div class="card-row">
                    <span class="card-label">Student:</span>
                    <span class="card-value"><?= htmlspecialchars($row['student_name']) ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Faculty:</span>
                    <span class="card-value"><?= htmlspecialchars($row['faculty_name']) ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Course:</span>
                    <span class="card-value"><?= $row['course'] ?></span>
                </div>
                <div class="card-row">
                    <span class="card-label">Subject:</span>
                    <span class="card-value"><?= htmlspecialchars($row['subject']) ?></span>
                </div>
            </div>
            <?php 
                endwhile;
            else:
            ?>
            <div class="no-records">📭 No attendance records found</div>
            <?php endif; ?>
        </div>
    </div>

    <center>
        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </center>
</div>

<script>
function exportToCSV() {
    let csv = 'Date,Student,Faculty,Course,Subject,Status\n';
    const table = document.getElementById('attendanceTable');
    
    if (!table) {
        alert('No data to export');
        return;
    }
    
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        const rowData = [];
        cols.forEach((col, idx) => {
            let text = col.textContent.trim();
            // Handle status badge and course badge
            text = text.replace(/\s+/g, ' ');
            rowData.push('"' + text + '"');
        });
        csv += rowData.join(',') + '\n';
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'attendance_records_' + new Date().toISOString().split('T')[0] + '.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}
</script>

</body>
</html>