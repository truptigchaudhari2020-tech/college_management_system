<!DOCTYPE html>
<html>
<head>
    <title>College Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Navbar - Mobile App Style */
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .navbar-brand {
            font-size: 18px;
            font-weight: 700;
            color: #667eea;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .navbar-menu {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .navbar a {
            color: #667eea;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .navbar a:hover {
            background: #667eea;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        /* Mobile Menu Toggle */
        .menu-toggle {
            display: none;
            flex-direction: column;
            gap: 4px;
            cursor: pointer;
            padding: 8px;
        }

        .menu-toggle span {
            width: 25px;
            height: 3px;
            background: #667eea;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        /* Hero Section - Mobile App Style */
        .hero {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.9) 0%, rgba(118, 75, 162, 0.9) 100%);
            color: white;
            padding: 60px 20px 80px;
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero::before {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -150px;
            right: -150px;
            animation: float 6s ease-in-out infinite;
        }

        .hero::after {
            content: '';
            position: absolute;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            bottom: -100px;
            left: -100px;
            animation: float 8s ease-in-out infinite reverse;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0) rotate(0deg);
            }
            50% {
                transform: translateY(-20px) rotate(180deg);
            }
        }

        .hero h1 {
            font-size: clamp(24px, 6vw, 40px);
            margin-bottom: 16px;
            font-weight: 700;
            position: relative;
            z-index: 1;
            animation: slideUp 0.8s ease-out 0.2s both;
        }

        .hero p {
            font-size: clamp(14px, 4vw, 18px);
            opacity: 0.95;
            position: relative;
            z-index: 1;
            animation: slideUp 0.8s ease-out 0.4s both;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: -40px auto 0;
            padding: 0 20px 40px;
            position: relative;
            z-index: 10;
        }

        .intro-section {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            animation: slideUp 0.8s ease-out 0.6s both;
        }

        .intro-section h2 {
            color: #667eea;
            font-size: clamp(22px, 5vw, 28px);
            margin-bottom: 12px;
        }

        .intro-section p {
            color: #666;
            font-size: clamp(14px, 3.5vw, 16px);
            line-height: 1.6;
        }

        /* Features Grid - Mobile Card Style */
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .feature-box {
            background: white;
            padding: 30px 25px;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            cursor: pointer;
            position: relative;
            overflow: hidden;
            animation: scaleIn 0.5s ease-out both;
        }

        .feature-box:nth-child(1) { animation-delay: 0.1s; }
        .feature-box:nth-child(2) { animation-delay: 0.2s; }
        .feature-box:nth-child(3) { animation-delay: 0.3s; }
        .feature-box:nth-child(4) { animation-delay: 0.4s; }
        .feature-box:nth-child(5) { animation-delay: 0.5s; }
        .feature-box:nth-child(6) { animation-delay: 0.6s; }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.8);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .feature-box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.4s ease;
        }

        .feature-box:hover::before {
            transform: scaleX(1);
        }

        .feature-box:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 15px 50px rgba(102, 126, 234, 0.3);
        }

        .feature-box h3 {
            font-size: clamp(18px, 4vw, 22px);
            margin-bottom: 12px;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .feature-box h3::before {
            content: attr(data-icon);
            font-size: 32px;
            display: inline-block;
            animation: bounce 2s ease-in-out infinite;
        }

        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .feature-box p {
            color: #666;
            font-size: clamp(13px, 3.5vw, 15px);
            line-height: 1.6;
        }

        /* Footer */
        .footer {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            color: #667eea;
            padding: 25px 20px;
            text-align: center;
            font-size: 14px;
            font-weight: 500;
            animation: fadeIn 1s ease-out;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .navbar-menu {
                position: fixed;
                top: 60px;
                left: 0;
                right: 0;
                background: rgba(255, 255, 255, 0.98);
                backdrop-filter: blur(10px);
                flex-direction: column;
                padding: 20px;
                gap: 12px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                transform: translateY(-150%);
                transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            }

            .navbar-menu.active {
                transform: translateY(0);
            }

            .menu-toggle {
                display: flex;
            }

            .menu-toggle.active span:nth-child(1) {
                transform: rotate(45deg) translate(5px, 5px);
            }

            .menu-toggle.active span:nth-child(2) {
                opacity: 0;
            }

            .menu-toggle.active span:nth-child(3) {
                transform: rotate(-45deg) translate(7px, -6px);
            }

            .navbar a {
                width: 100%;
                text-align: center;
                padding: 12px;
            }

            .features {
                grid-template-columns: 1fr;
            }

            .hero {
                padding: 40px 20px 60px;
            }

            .container {
                margin-top: -30px;
            }

            .intro-section {
                padding: 25px 20px;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Loading Animation */
        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.5;
            }
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="navbar-brand">
        🎓 College CMS
    </div>
    <div class="menu-toggle" onclick="toggleMenu()">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <div class="navbar-menu" id="navMenu">
        <a href="index.php">Home</a>
        <a href="auth/login.php">Login</a>
        <a href="auth/student_register.php">Register</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">
    <h1>Welcome to DCPE HVPM</h1>
    <p>A complete digital solution for managing college operations efficiently</p>
</div>

<!-- CONTENT -->
<div class="container">
    <div class="intro-section">
        <h2>Why Choose Our CMS?</h2>
        <p>A central platform to automate academic and administrative tasks with ease and efficiency.</p>
    </div>

    <div class="features">
        <div class="feature-box">
            <h3 data-icon="📝">Student Management</h3>
            <p>Register, update profiles, view attendance and results seamlessly.</p>
        </div>

        <div class="feature-box">
            <h3 data-icon="👨‍🏫">Faculty Portal</h3>
            <p>Assign subjects, upload marks, manage students efficiently.</p>
        </div>

        <div class="feature-box">
            <h3 data-icon="📚">Library System</h3>
            <p>Track book availability, issues, and return dates digitally.</p>
        </div>

        <div class="feature-box">
            <h3 data-icon="🗓">Attendance Tracking</h3>
            <p>Subject-wise attendance maintained by faculty members.</p>
        </div>

        <div class="feature-box">
            <h3 data-icon="📊">Results & Exam</h3>
            <p>Unit test and semester exam results uploaded digitally.</p>
        </div>

        <div class="feature-box">
            <h3 data-icon="📢">Notice Board</h3>
            <p>Admin can publish important college notices instantly.</p>
        </div>
    </div>
</div>

<!-- FOOTER -->
<div class="footer">
    © 2025 DCPE HVPM Amravati • College Management System
</div>

<script>
    function toggleMenu() {
        const menu = document.getElementById('navMenu');
        const toggle = document.querySelector('.menu-toggle');
        menu.classList.toggle('active');
        toggle.classList.toggle('active');
    }

    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        const menu = document.getElementById('navMenu');
        const toggle = document.querySelector('.menu-toggle');
        const navbar = document.querySelector('.navbar');
        
        if (!navbar.contains(event.target)) {
            menu.classList.remove('active');
            toggle.classList.remove('active');
        }
    });

    // Add intersection observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.feature-box').forEach(box => {
        observer.observe(box);
    });
</script>

</body>
</html>