<!DOCTYPE html>
<html>
<head>
    <title>Contact Us - College Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
            padding-bottom: 40px;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.95) 0%, rgba(118, 75, 162, 0.95) 100%);
            backdrop-filter: blur(10px);
            color: white;
            padding: 50px 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header::before {
            content: '📧';
            position: absolute;
            font-size: 120px;
            opacity: 0.1;
            right: -20px;
            top: 50%;
            transform: translateY(-50%) rotate(-15deg);
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(-50%) rotate(-15deg);
            }
            50% {
                transform: translateY(-60%) rotate(-10deg);
            }
        }

        .header h2 {
            font-size: clamp(28px, 6vw, 36px);
            font-weight: 700;
            position: relative;
            z-index: 1;
            animation: slideUp 0.8s ease-out 0.2s both;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Container */
        .container {
            max-width: 600px;
            margin: -30px auto 0;
            padding: 0 20px;
            position: relative;
            z-index: 10;
        }

        /* Info Card */
        .info-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
            animation: scaleIn 0.6s ease-out 0.3s both;
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .info-card p {
            color: #555;
            line-height: 1.8;
            font-size: clamp(14px, 3.5vw, 16px);
            margin-bottom: 25px;
        }

        /* Form Card */
        .form-card {
            background: white;
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
            animation: scaleIn 0.6s ease-out 0.5s both;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        /* Input Fields - Mobile App Style */
        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 16px 20px;
            border: 2px solid #e0e4e8;
            border-radius: 12px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: #f8f9fa;
            color: #2c3e50;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        textarea:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }

        textarea {
            min-height: 140px;
            resize: vertical;
            font-family: inherit;
        }

        /* Placeholder Animation */
        input::placeholder,
        textarea::placeholder {
            color: #999;
            transition: all 0.3s ease;
        }

        input:focus::placeholder,
        textarea:focus::placeholder {
            opacity: 0.5;
            transform: translateX(5px);
        }

        /* Submit Button - Mobile App Style */
        button[type="submit"] {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
            position: relative;
            overflow: hidden;
        }

        button[type="submit"]::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: left 0.5s ease;
        }

        button[type="submit"]:hover::before {
            left: 100%;
        }

        button[type="submit"]:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
        }

        button[type="submit"]:active {
            transform: translateY(-1px);
            box-shadow: 0 6px 15px rgba(102, 126, 234, 0.3);
        }

        /* Contact Info Card */
        .contact-info {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
            animation: scaleIn 0.6s ease-out 0.7s both;
        }

        .contact-detail {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 16px;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            border-radius: 12px;
            margin-bottom: 12px;
            transition: all 0.3s ease;
            border-left: 4px solid #667eea;
        }

        .contact-detail:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.2);
        }

        .contact-detail:last-child {
            margin-bottom: 0;
        }

        .contact-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        .contact-text {
            flex: 1;
        }

        .contact-text strong {
            display: block;
            color: #2c3e50;
            font-size: 13px;
            margin-bottom: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .contact-text span {
            color: #667eea;
            font-size: 16px;
            font-weight: 600;
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            justify-content: center;
            padding: 16px 28px;
            background: white;
            color: #667eea;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            animation: scaleIn 0.6s ease-out 0.9s both;
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        .back-btn:active {
            transform: translateY(-1px);
        }

        /* Divider */
        .divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, #667eea, transparent);
            margin: 25px 0;
            opacity: 0.3;
        }

        /* Input Animation on Load */
        input, textarea, button {
            animation: fadeInUp 0.5s ease-out both;
        }

        input:nth-of-type(1) { animation-delay: 0.6s; }
        input:nth-of-type(2) { animation-delay: 0.7s; }
        input:nth-of-type(3) { animation-delay: 0.8s; }
        textarea { animation-delay: 0.9s; }
        button { animation-delay: 1s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 40px 20px;
            }

            .container {
                margin: -20px auto 0;
            }

            .info-card,
            .form-card,
            .contact-info {
                padding: 25px 20px;
                border-radius: 16px;
            }

            .contact-detail {
                padding: 14px;
            }

            .contact-icon {
                width: 40px;
                height: 40px;
                font-size: 18px;
            }

            input[type="text"],
            input[type="email"],
            textarea {
                padding: 14px 16px;
                font-size: 16px; /* Prevents iOS zoom on focus */
            }

            button[type="submit"] {
                padding: 15px;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }
    </style>
</head>
<body>

<div class="header">
    <h2>📬 Contact Us</h2>
</div>

<div class="container">
    <div class="info-card">
        <p>
            For any queries related to admission, courses, or system support, please contact us.
            We're here to help you with all your questions!
        </p>
    </div>

    <div class="form-card">
        <form>
            <input type="text" placeholder="Full Name" required>
            <input type="email" placeholder="Email Address" required>
            <input type="text" placeholder="Mobile Number" required>
            <textarea placeholder="Your Message" required></textarea>
            <button type="submit">Send Message ✉️</button>
        </form>
    </div>

    <div class="contact-info">
        <div class="contact-detail">
            <div class="contact-icon">📧</div>
            <div class="contact-text">
                <strong>Email</strong>
                <span>support@cms.com</span>
            </div>
        </div>

        <div class="contact-detail">
            <div class="contact-icon">📱</div>
            <div class="contact-text">
                <strong>Phone</strong>
                <span>+91 99999 99999</span>
            </div>
        </div>
    </div>

    <a class="back-btn" href="index.php">
        <span>⬅</span>
        <span>Back to Home</span>
    </a>
</div>

</body>
</html>