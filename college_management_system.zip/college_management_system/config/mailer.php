<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// LOAD PHPMailer
require_once __DIR__ . "/../vendor/phpmailer/phpmailer/src/Exception.php";
require_once __DIR__ . "/../vendor/phpmailer/phpmailer/src/PHPMailer.php";
require_once __DIR__ . "/../vendor/phpmailer/phpmailer/src/SMTP.php";

function sendMail($to, $subject, $body) {

    $mail = new PHPMailer(true);

    try {
        // SMTP SETTINGS
        $mail->isSMTP();
        $mail->Host       = "smtp.gmail.com";
        $mail->SMTPAuth   = true;

        // 🔥 Enter your Gmail + App Password here
        $mail->Username   = "ar40769000@gmail.com";  
        $mail->Password   = "pydrajgnpxhaxghe";  

        $mail->SMTPSecure = "tls";
        $mail->Port       = 587;

        // EMAIL HEADERS
        $mail->setFrom("ar40769000@gmail.com", "College Management System");
        $mail->addAddress($to);

        // CONTENT
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
}
?>
