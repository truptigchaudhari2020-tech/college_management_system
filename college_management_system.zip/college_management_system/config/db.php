<?php
// config/db.php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "cms";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
