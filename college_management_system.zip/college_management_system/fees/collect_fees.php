<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$msg = "";

// Fetch students
$students = $conn->query("SELECT id, full_name FROM users WHERE role='student'");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $student_id = $_POST['student_id'];
    $fee_type   = $_POST['fee_type'];
    $amount     = $_POST['amount'];

    $stmt = $conn->prepare("
        INSERT INTO fees (student_id, fee_type, amount, payment_date, status)
        VALUES (?, ?, ?, CURDATE(), 'Paid')
    ");
    $stmt->bind_param("isd", $student_id, $fee_type, $amount);
    $stmt->execute();

    $msg = "Fee collected successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Collect Fees</title>
</head>
<body>

<h2>Collect Fees</h2>

<form method="POST">
    <select name="student_id" required>
        <option value="">Select Student</option>
        <?php while ($s = $students->fetch_assoc()) { ?>
            <option value="<?= $s['id'] ?>"><?= $s['full_name'] ?></option>
        <?php } ?>
    </select><br><br>

    <select name="fee_type" required>
        <option value="">Fee Type</option>
        <option value="Admission">Admission</option>
        <option value="Exam">Exam</option>
        <option value="Other">Other</option>
    </select><br><br>

    <input type="number" name="amount" placeholder="Amount" required><br><br>

    <button type="submit">Collect Fee</button>
</form>

<p><?= $msg ?></p>

<a href="../admin/dashboard.php">⬅ Back</a>

</body>
</html>
