<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

$student_id = $_SESSION['user_id'];

$result = $conn->query("
    SELECT fee_type, amount, status, payment_date
    FROM fees
    WHERE student_id = $student_id
    ORDER BY payment_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Fee History</title>
</head>
<body>

<h2>My Fee History</h2>

<table border="1" cellpadding="8">
<tr>
    <th>Date</th>
    <th>Fee Type</th>
    <th>Amount</th>
    <th>Status</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['payment_date'] ?></td>
    <td><?= $row['fee_type'] ?></td>
    <td>₹<?= $row['amount'] ?></td>
    <td><?= $row['status'] ?></td>
</tr>
<?php } ?>

</table>

<br>
<a href="../student/dashboard.php">⬅ Back</a>

</body>
</html>
