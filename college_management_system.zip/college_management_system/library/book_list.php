<?php
require_once "../config/session.php";
require_once "../config/db.php";

$result = $conn->query("SELECT * FROM library_books");
?>

<!DOCTYPE html>
<html>
<head><title>Library Books</title></head>
<body>

<h2>Library Books</h2>

<table border="1" cellpadding="8">
<tr>
    <th>Book</th>
    <th>Author</th>
    <th>Course</th>
    <th>Available Qty</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['book_name'] ?></td>
    <td><?= $row['author'] ?></td>
    <td><?= $row['course'] ?></td>
    <td><?= $row['quantity'] ?></td>
</tr>
<?php } ?>

</table>

<a href="../student/dashboard.php">⬅ Back</a>

</body>
</html>
