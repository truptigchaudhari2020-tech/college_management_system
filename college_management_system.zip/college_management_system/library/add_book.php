<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $book = $_POST['book_name'];
    $author = $_POST['author'];
    $course = $_POST['course'];
    $qty = $_POST['quantity'];

    $stmt = $conn->prepare(
        "INSERT INTO library_books (book_name, author, course, quantity)
         VALUES (?,?,?,?)"
    );
    $stmt->bind_param("sssi", $book, $author, $course, $qty);
    $stmt->execute();

    $msg = "Book added successfully!";
}
?>

<!DOCTYPE html>
<html>
<head><title>Add Book</title></head>
<body>

<h2>Add Book</h2>

<form method="POST">
<input name="book_name" placeholder="Book Name" required><br><br>
<input name="author" placeholder="Author" required><br><br>

<select name="course">
<option>MCA</option>
<option>MSC</option>
<option>BCA</option>
<option>BSC</option>
</select><br><br>

<input type="number" name="quantity" min="1" placeholder="Quantity" required><br><br>

<button>Add Book</button>
</form>

<p><?= $msg ?></p>
<a href="../admin/dashboard.php">⬅ Back</a>

</body>
</html>
