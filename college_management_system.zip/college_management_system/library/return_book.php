<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$issued = $conn->query("
    SELECT bi.id, lb.book_name
    FROM book_issue bi
    JOIN library_books lb ON bi.book_id = lb.id
    WHERE bi.status='Issued'
");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $issue_id = $_POST['issue_id'];

    $conn->query("UPDATE book_issue SET status='Returned', return_date=CURDATE() WHERE id=$issue_id");

    $conn->query("
        UPDATE library_books lb
        JOIN book_issue bi ON lb.id = bi.book_id
        SET lb.quantity = lb.quantity + 1
        WHERE bi.id = $issue_id
    ");

    echo "<script>alert('Book Returned Successfully');</script>";
}
?>

<!DOCTYPE html>
<html>
<head><title>Return Book</title></head>
<body>

<h2>Return Book</h2>

<form method="POST">
<select name="issue_id" required>
<?php while ($row = $issued->fetch_assoc()) { ?>
<option value="<?= $row['id'] ?>"><?= $row['book_name'] ?></option>
<?php } ?>
</select><br><br>

<button>Return Book</button>
</form>

<a href="../admin/dashboard.php">⬅ Back</a>

</body>
</html>
