<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('admin');

$books = $conn->query("SELECT * FROM library_books WHERE quantity > 0");
$students = $conn->query("SELECT id, full_name FROM users WHERE role='student'");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $book_id = $_POST['book_id'];
    $student_id = $_POST['student_id'];

    $conn->query("
        INSERT INTO book_issue (book_id, student_id, issue_date)
        VALUES ($book_id, $student_id, CURDATE())
    ");

    $conn->query("
        UPDATE library_books SET quantity = quantity - 1 WHERE id = $book_id
    ");

    echo "<script>alert('Book Issued Successfully');</script>";
}
?>

<!DOCTYPE html>
<html>
<head><title>Issue Book</title></head>
<body>

<h2>Issue Book</h2>

<form method="POST">

<select name="book_id" required>
<?php while ($b = $books->fetch_assoc()) { ?>
<option value="<?= $b['id'] ?>"><?= $b['book_name'] ?></option>
<?php } ?>
</select><br><br>

<select name="student_id" required>
<?php while ($s = $students->fetch_assoc()) { ?>
<option value="<?= $s['id'] ?>"><?= $s['full_name'] ?></option>
<?php } ?>
</select><br><br>

<button>Issue Book</button>
</form>

<a href="../admin/dashboard.php">⬅ Back</a>

</body>
</html>
