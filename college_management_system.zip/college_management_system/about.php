<!DOCTYPE html>
<html>
<head>
    <title>About Us - College Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Header with Animation */
        .header {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.95) 0%, rgba(118, 75, 162, 0.95) 100%);
            backdrop-filter: blur(10px);
            color: white;
            padding: 50px 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header::before {
            content: '';
            position: absolute;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            right: -50px;
            animation: float 6s ease-in-out infinite;
        }

        .header::after {
            content: '';
            position: absolute;
            width: 150px;
            height: 150px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
            bottom: -75px;
            left: -30px;
            animation: float 8s ease-in-out infinite reverse;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0) rotate(0deg);
            }
            50% {
                transform: translateY(-20px) rotate(180deg);
            }
        }

        .header h1 {
            font-size: clamp(24px, 6vw, 36px);
            font-weight: 700;
            position: relative;
            z-index: 1;
            animation: slideUp 0.8s ease-out 0.2s both;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Container */
        .container {
            max-width: 900px;
            margin: -30px auto 40px;
            padding: 0 20px;
            position: relative;
            z-index: 10;
            animation: slideUp 0.8s ease-out 0.4s both;
        }

        .content-card {
            background: white;
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .content-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.2);
        }

        .content-card p {
            color: #555;
            line-height: 1.8;
            font-size: clamp(14px, 3.5vw, 16px);
            margin-bottom: 16px;
        }

        .content-card p b {
            color: #667eea;
        }

        h2, h3 {
            color: #2c3e50;
            margin: 25px 0 16px;
            font-weight: 700;
        }

        h2 {
            font-size: clamp(22px, 5vw, 28px);
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.6s ease-out;
        }

        h3 {
            font-size: clamp(18px, 4.5vw, 22px);
            display: flex;
            align-items: center;
            gap: 8px;
            color: #667eea;
        }

        /* College Box - Card Style */
        .college-box {
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecf3 100%);
            padding: 25px;
            border-left: 5px solid #667eea;
            border-radius: 15px;
            margin: 25px 0;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
            animation: scaleIn 0.6s ease-out;
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .college-box::before {
            content: '🏫';
            position: absolute;
            right: 20px;
            top: 20px;
            font-size: 60px;
            opacity: 0.1;
        }

        .college-box p {
            color: #444;
            line-height: 1.7;
            margin-bottom: 14px;
            position: relative;
            z-index: 1;
        }

        /* Styled List */
        ul {
            list-style: none;
            padding-left: 0;
        }

        ul li {
            margin: 12px 0;
            padding-left: 30px;
            position: relative;
            color: #555;
            font-size: clamp(14px, 3.5vw, 16px);
            line-height: 1.6;
            animation: slideRight 0.5s ease-out both;
        }

        ul li:nth-child(1) { animation-delay: 0.1s; }
        ul li:nth-child(2) { animation-delay: 0.2s; }
        ul li:nth-child(3) { animation-delay: 0.3s; }
        ul li:nth-child(4) { animation-delay: 0.4s; }
        ul li:nth-child(5) { animation-delay: 0.5s; }
        ul li:nth-child(6) { animation-delay: 0.6s; }
        ul li:nth-child(7) { animation-delay: 0.7s; }
        ul li:nth-child(8) { animation-delay: 0.8s; }

        @keyframes slideRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        ul li::before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #667eea;
            font-weight: bold;
            font-size: 18px;
            width: 24px;
            height: 24px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        /* Tech Stack */
        .tech-section ul li b {
            color: #667eea;
            font-weight: 600;
        }

        /* Back Button - Mobile App Style */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 30px;
            padding: 14px 28px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .back-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: left 0.5s ease;
        }

        .back-btn:hover::before {
            left: 100%;
        }

        .back-btn:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
        }

        .back-btn:active {
            transform: translateY(-1px) scale(1.02);
        }

        /* Section Divider */
        .section-divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, #667eea, transparent);
            margin: 30px 0;
            opacity: 0.3;
        }

        /* Feature Box */
        .feature-highlight {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            padding: 20px;
            border-radius: 12px;
            margin: 20px 0;
            border: 2px solid rgba(102, 126, 234, 0.2);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 40px 20px;
            }

            .container {
                margin: -20px auto 30px;
            }

            .content-card {
                padding: 25px 20px;
                border-radius: 16px;
            }

            .college-box {
                padding: 20px;
            }

            .college-box::before {
                font-size: 40px;
                right: 15px;
                top: 15px;
            }

            ul li {
                padding-left: 28px;
            }

            .back-btn {
                width: 100%;
                justify-content: center;
                padding: 16px 28px;
            }

            h2, h3 {
                margin: 20px 0 12px;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }
    </style>
</head>
<body>

<div class="header">
    <h1>About College Management System</h1>
</div>

<div class="container">
    <div class="content-card">
        <p>
            The <b>College Management System (CMS)</b> is a complete web-based solution designed to
            streamline and digitalize day-to-day academic and administrative operations of a college.
        </p>

        <p>
            It reduces manual work, improves accuracy, centralizes student and faculty data, and enhances
            communication between students, faculty members, and administrators.
        </p>

        <div class="section-divider"></div>

        <h2>🏫 About DCPE HVPM, Amravati</h2>

        <div class="college-box">
            <p>
                <b>Department of Computer Programming & Engineering (DCPE),</b>  
                located in the historic Hanuman Vyayam Prasarak Mandal (HVPM) campus, Amravati,  
                is a premier institute known for its disciplined environment and quality technical education.
            </p>

            <p>
                DCPE is recognized for offering programs such as:
            </p>
            <ul>
                <li>MCA – Master of Computer Applications</li>
                <li>BCA – Bachelor of Computer Applications</li>
                <li>B.Sc (Computer Science)</li>
                <li>MSC (Computer Science)</li>
            </ul>

            <p>
                The institute focuses not only on academics but also on practical exposure,  
                personality development, and real-world project training.
            </p>
        </div>

        <div class="section-divider"></div>

        <h3>✨ Key Features of Our CMS</h3>
        <div class="feature-highlight">
            <ul>
                <li>Student Registration & Profile Management</li>
                <li>Faculty Management & Course Allocation</li>
                <li>Subject-wise Attendance System</li>
                <li>Exam & Unit Test Result Upload</li>
                <li>Fees Management with Category-wise Structure</li>
                <li>Library Book Issue & Return Tracking</li>
                <li>Centralized Notice Board</li>
                <li>Admin, Faculty & Student Portals</li>
            </ul>
        </div>

        <div class="section-divider"></div>

        <h3>🛠 Technologies Used</h3>
        <div class="tech-section">
            <ul>
                <li><b>Frontend:</b> HTML, CSS, JavaScript</li>
                <li><b>Backend:</b> PHP</li>
                <li><b>Database:</b> MySQL</li>
                <li><b>Local Server:</b> XAMPP</li>
            </ul>
        </div>

        <div class="section-divider"></div>

        <h3>🎯 Project Purpose</h3>
        <p>
            The purpose of this system is to automate college operations, maintain accurate records,
            and provide a smooth digital experience to students and faculty members.
        </p>

        <a class="back-btn" href="index.php">
            <span>⬅</span>
            <span>Back to Home</span>
        </a>
    </div>
</div>

</body>
</html>