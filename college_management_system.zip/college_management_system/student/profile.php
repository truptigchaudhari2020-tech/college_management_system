<?php
require_once "../config/session.php";
require_once "../config/db.php";
require_once "../config/auth_check.php";
checkRole('student');

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM users WHERE id=? AND role='student'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Container */
        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        /* Header */
        .page-header {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            text-align: center;
            animation: slideDown 0.6s ease-out;
            position: relative;
            overflow: hidden;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header::before {
            content: '👤';
            position: absolute;
            font-size: 150px;
            opacity: 0.05;
            right: -20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .profile-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            animation: bounce 2s ease-in-out infinite;
            position: relative;
            z-index: 1;
        }

        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .page-header h2 {
            color: #2c3e50;
            font-size: clamp(24px, 5vw, 30px);
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            color: #667eea;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            position: relative;
            z-index: 1;
        }

        /* Profile Card */
        .profile-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out 0.2s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .profile-card::before {
            content: '';
            display: block;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        /* Profile Info Grid */
        .profile-info {
            padding: 35px;
        }

        .info-row {
            display: grid;
            grid-template-columns: 140px 1fr;
            gap: 20px;
            padding: 18px 0;
            border-bottom: 2px solid #f0f2f5;
            animation: slideRight 0.5s ease-out both;
        }

        .info-row:nth-child(1) { animation-delay: 0.3s; }
        .info-row:nth-child(2) { animation-delay: 0.4s; }
        .info-row:nth-child(3) { animation-delay: 0.5s; }
        .info-row:nth-child(4) { animation-delay: 0.6s; }
        .info-row:nth-child(5) { animation-delay: 0.7s; }
        .info-row:nth-child(6) { animation-delay: 0.8s; }
        .info-row:nth-child(7) { animation-delay: 0.9s; }

        @keyframes slideRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .info-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }

        .info-label {
            font-weight: 600;
            color: #667eea;
            font-size: clamp(13px, 3.5vw, 15px);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-label::before {
            content: attr(data-icon);
            font-size: 20px;
        }

        .info-value {
            color: #2c3e50;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 500;
            display: flex;
            align-items: center;
            padding: 12px 18px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            border: 2px solid #e0e4e8;
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 32px;
            background: white;
            color: #667eea;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-top: 25px;
            animation: fadeIn 0.6s ease-out 1s both;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        .back-btn:active {
            transform: translateY(-1px);
        }

        /* Action Buttons Section */
        .action-section {
            padding: 25px 35px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-top: 2px solid #e0e4e8;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .action-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 14px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 15px;
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
            transition: all 0.3s ease;
        }

        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .page-header {
                padding: 25px 20px;
            }

            .profile-icon {
                width: 80px;
                height: 80px;
                font-size: 40px;
                margin-bottom: 16px;
            }

            .profile-info {
                padding: 25px 20px;
            }

            .info-row {
                grid-template-columns: 1fr;
                gap: 8px;
                padding: 14px 0;
            }

            .info-label {
                font-weight: 700;
                color: #2c3e50;
            }

            .info-value {
                padding: 10px 14px;
            }

            .action-section {
                padding: 20px;
            }

            .action-buttons {
                grid-template-columns: 1fr;
            }

            .back-btn {
                width: 100%;
                justify-content: center;
                padding: 16px 28px;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }

        /* Badge for Course */
        .course-badge {
            display: inline-block;
            padding: 6px 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
    </style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <div class="profile-icon">👤</div>
        <h2><?= htmlspecialchars($student['full_name']); ?></h2>
        <p>Student Profile</p>
    </div>

    <div class="profile-card">
        <div class="profile-info">
            
            <div class="info-row">
                <div class="info-label" data-icon="👤">Full Name</div>
                <div class="info-value"><?= htmlspecialchars($student['full_name']); ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="📅">Date of Birth</div>
                <div class="info-value"><?= htmlspecialchars($student['dob']); ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="📱">Mobile</div>
                <div class="info-value"><?= htmlspecialchars($student['mobile']); ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="📧">Email</div>
                <div class="info-value"><?= htmlspecialchars($student['email']); ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="🔤">Username</div>
                <div class="info-value"><?= htmlspecialchars($student['username']); ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="📚">Course</div>
                <div class="info-value">
                    <span class="course-badge"><?= htmlspecialchars($student['course']); ?></span>
                </div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="🏷️">Caste Category</div>
                <div class="info-value"><?= htmlspecialchars($student['caste_category']); ?></div>
            </div>

        </div>

        <div class="action-section">
            <div class="action-buttons">
                <a href="edit_profile.php" class="action-btn">
                    <span>✏️</span>
                    <span>Edit Profile</span>
                </a>
                <a href="change_password.php" class="action-btn">
                    <span>🔒</span>
                    <span>Change Password</span>
                </a>
            </div>
        </div>
    </div>

    <a href="dashboard.php" class="back-btn">
        <span>⬅</span>
        <span>Back to Dashboard</span>
    </a>

</div>

</body>
</html>