<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

$student_id = $_SESSION['user_id'];

/* SUBJECT-WISE SUMMARY */
$summary = $conn->query("
    SELECT 
        subject,
        COUNT(*) AS total_classes,
        SUM(status = 'Present') AS present_count,
        SUM(status = 'Absent') AS absent_count
    FROM attendance
    WHERE student_id = $student_id
    GROUP BY subject
");

/* FULL DAILY RECORDS */
$records = $conn->query("
    SELECT attendance_date, subject, status
    FROM attendance
    WHERE student_id = $student_id
    ORDER BY attendance_date DESC
");

/* MONTHLY GRAPH DATA */
$monthly = $conn->query("
    SELECT 
        DATE_FORMAT(attendance_date, '%Y-%m') AS month,
        subject,
        SUM(status = 'Present') AS present_count
    FROM attendance
    WHERE student_id = $student_id
    GROUP BY month, subject
    ORDER BY month ASC
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Attendance</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Header */
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            animation: slideDown 0.6s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header h2 {
            color: #2c3e50;
            font-size: clamp(22px, 5vw, 28px);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Box - Card Style */
        .box {
            background: white;
            margin-bottom: 25px;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out both;
        }

        .box:nth-child(1) { animation-delay: 0.1s; }
        .box:nth-child(2) { animation-delay: 0.2s; }
        .box:nth-child(3) { animation-delay: 0.3s; }
        .box:nth-child(4) { animation-delay: 0.4s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .box h3 {
            color: #2c3e50;
            font-size: clamp(18px, 4vw, 22px);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .box h2 {
            color: #2c3e50;
            font-size: clamp(20px, 4.5vw, 24px);
            margin-bottom: 20px;
        }

        /* Alert Messages */
        .warning, .safe, .medium {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
            font-size: clamp(13px, 3.5vw, 15px);
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideRight 0.5s ease-out;
        }

        @keyframes slideRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .warning {
            background: linear-gradient(135deg, #ffe5e5 0%, #ffd4d4 100%);
            color: #c0392b;
            border-left: 5px solid #e74c3c;
        }

        .safe {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            border-left: 5px solid #28a745;
        }

        .medium {
            background: linear-gradient(135deg, #fff4cc 0%, #ffe9a3 100%);
            color: #856404;
            border-left: 5px solid #ffc107;
        }

        /* Chart Container */
        .chart-container {
            position: relative;
            max-width: 300px;
            margin: 20px auto;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 16px;
        }

        canvas {
            max-height: 300px;
        }

        /* Stats Display */
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .stat-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 16px;
            border-radius: 12px;
            text-align: center;
            border: 2px solid #e0e4e8;
        }

        .stat-item b {
            display: block;
            color: #667eea;
            font-size: clamp(11px, 3vw, 13px);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }

        .stat-item span {
            display: block;
            color: #2c3e50;
            font-size: clamp(20px, 5vw, 28px);
            font-weight: 700;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            overflow: hidden;
            border-radius: 12px;
        }

        table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        table th {
            color: white;
            padding: 16px;
            text-align: left;
            font-size: clamp(13px, 3.5vw, 15px);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        table td {
            padding: 14px 16px;
            border-bottom: 1px solid #e0e4e8;
            color: #2c3e50;
            font-size: clamp(13px, 3.5vw, 15px);
        }

        table tbody tr {
            background: white;
            transition: all 0.3s ease;
        }

        table tbody tr:hover {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            transform: scale(1.01);
        }

        table tbody tr:last-child td {
            border-bottom: none;
        }

        /* Status Badge */
        table td:last-child {
            font-weight: 600;
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 28px;
            background: white;
            color: #667eea;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin: 20px 0;
            animation: fadeIn 0.6s ease-out 0.5s both;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        /* Responsive Table */
        .table-wrapper {
            overflow-x: auto;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .page-header {
                padding: 20px;
            }

            .box {
                padding: 20px;
                margin-bottom: 20px;
            }

            .chart-container {
                max-width: 100%;
                padding: 15px;
            }

            table th,
            table td {
                padding: 12px 10px;
                font-size: 13px;
            }

            .stats {
                grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
                gap: 10px;
            }

            .back-btn {
                width: 100%;
                justify-content: center;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Loading Animation */
        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.5;
            }
        }

        /* Chart responsive */
        #monthlyChart {
            max-height: 400px;
        }
    </style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <h2>📊 My Attendance Overview</h2>
    </div>

    <?php while ($row = $summary->fetch_assoc()) { 
        $subject = $row['subject'];
        $total = $row['total_classes'];
        $present = $row['present_count'];
        $absent = $row['absent_count'];

        $percent = $total > 0 ? round(($present / $total) * 100) : 0;
        $chartId = "chart_" . md5($subject);
    ?>

    <div class="box">

        <!-- Warning Message -->
        <?php if ($percent < 75) { ?>
            <div class="warning">⚠️ Warning: Your attendance in <b><?= $subject ?></b> is below 75% (<?= $percent ?>%)</div>
        <?php } elseif ($percent < 80) { ?>
            <div class="medium">⚠️ Attendance slightly low in <b><?= $subject ?></b> (<?= $percent ?>%)</div>
        <?php } else { ?>
            <div class="safe">✔ Good attendance in <b><?= $subject ?></b> (<?= $percent ?>%)</div>
        <?php } ?>

        <h3><?= $subject ?> — <?= $percent ?>%</h3>

        <div class="chart-container">
            <canvas id="<?= $chartId ?>"></canvas>
        </div>

        <script>
        new Chart(document.getElementById("<?= $chartId ?>"), {
            type: "pie",
            data: {
                labels: ["Present", "Absent"],
                datasets: [{
                    data: [<?= $present ?>, <?= $absent ?>],
                    backgroundColor: ["#4caf50", "#f44336"]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true
            }
        });
        </script>

        <div class="stats">
            <div class="stat-item">
                <b>Total</b>
                <span><?= $total ?></span>
            </div>
            <div class="stat-item">
                <b>Present</b>
                <span><?= $present ?></span>
            </div>
            <div class="stat-item">
                <b>Absent</b>
                <span><?= $absent ?></span>
            </div>
        </div>
    </div>

    <?php } ?>


    <!-- MONTHLY GRAPH -->
    <div class="box">
        <h2>📅 Monthly Faculty-wise Attendance Graph</h2>

        <div class="chart-container" style="max-width: 100%;">
            <canvas id="monthlyChart"></canvas>
        </div>

        <script>
            const monthlyLabels = [];
            const monthlyValues = [];

            <?php 
            $data = [];
            while ($m = $monthly->fetch_assoc()) {
                $label = $m['month'] . " (" . $m['subject'] . ")";
                $data[] = ["label"=>$label, "value"=>$m['present_count']];
            }
            foreach ($data as $d) { 
            ?>
                monthlyLabels.push("<?= $d['label'] ?>");
                monthlyValues.push(<?= $d['value'] ?>);
            <?php } ?>

            new Chart(document.getElementById("monthlyChart"), {
                type: "bar",
                data: {
                    labels: monthlyLabels,
                    datasets: [{
                        label: "Present Count",
                        data: monthlyValues,
                        backgroundColor: "#667eea",
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
    </div>


    <!-- FULL DAILY ATTENDANCE TABLE -->
    <div class="box">
        <h2>📘 Full Attendance Record</h2>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Subject</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $records->fetch_assoc()) { ?>
                    <tr>
                        <td><?= $row['attendance_date'] ?></td>
                        <td><?= $row['subject'] ?></td>
                        <td><?= $row['status'] ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="dashboard.php" class="back-btn">
        <span>⬅</span>
        <span>Back to Dashboard</span>
    </a>

</div>

</body>
</html>