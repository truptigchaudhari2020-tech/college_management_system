<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

/* DELETE NOTICE (Student Side) */
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM notices WHERE id = $id");
    header("Location: notice.php");
    exit;
}

/* FETCH NOTICES */
$result = $conn->query("SELECT * FROM notices ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Notices</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .notice-box {
            border: 1px solid #ccc;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 6px;
            background: #f9f9f9;
        }
        .notice-title {
            font-weight: bold;
            font-size: 18px;
        }
        .notice-date {
            font-size: 12px;
            color: #666;
        }
        .delete-btn {
            color: red;
            text-decoration: none;
            font-weight: bold;
            float: right;
        }
    </style>
</head>
<body>

<h2>📢 College Notices</h2>

<?php if ($result->num_rows > 0) { ?>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <div class="notice-box">
            <a 
                href="?delete=<?= $row['id'] ?>" 
                class="delete-btn"
                onclick="return confirm('Delete this notice?');"
            >
                ❌ Delete
            </a>

            <div class="notice-title">
                <?= htmlspecialchars($row['title']) ?>
            </div>

            <p><?= nl2br(htmlspecialchars($row['message'])) ?></p>

            <div class="notice-date">
                Posted on: <?= $row['created_at'] ?>
            </div>
        </div>
    <?php } ?>

<?php } else { ?>
    <p>No notices available.</p>
<?php } ?>

<a href="dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
