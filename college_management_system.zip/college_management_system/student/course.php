<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

$student_id = $_SESSION['user_id'];

/* GET STUDENT COURSE */
$student = $conn->query("
    SELECT course 
    FROM users 
    WHERE id = $student_id
")->fetch_assoc();

$course = $student['course'];

/* GET SUBJECTS + FACULTY */
$result = $conn->query("
    SELECT 
        s.subject_name,
        u.full_name AS faculty_name
    FROM subjects s
    LEFT JOIN faculty_subjects fs ON fs.subject_id = s.id
    LEFT JOIN users u ON u.id = fs.faculty_id
    WHERE s.course = '$course'
");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Subjects</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f6f9;
        margin: 0;
        padding: 20px;
    }
    h2 {
        margin-bottom: 10px;
    }
    .subject-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        margin-top: 20px;
    }
    .subject-card {
        background: white;
        padding: 15px;
        border-radius: 10px;
        width: 240px;
        box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        transition: 0.3s;
    }
    .subject-card:hover {
        transform: scale(1.03);
    }
    .subject-card h3 {
        margin: 0;
        color: #2c3e50;
    }
    .teacher {
        margin-top: 8px;
        padding: 5px 8px;
        background: #16a085;
        color: white;
        display: inline-block;
        border-radius: 5px;
        font-size: 13px;
    }
    .teacher.pending {
        background: #7f8c8d;
    }
    .back-btn {
        display: inline-block;
        padding: 10px 15px;
        background: black;
        color: white;
        border-radius: 5px;
        text-decoration: none;
        margin-top: 25px;
    }
</style>
</head>
<body>

<h2>📘 My Course Subjects</h2>
<p><b>Course:</b> <?= $course ?></p>

<div class="subject-grid">

<?php 
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { 
        $faculty = $row['faculty_name'] 
                   ? htmlspecialchars($row['faculty_name']) 
                   : "<span class='teacher pending'>Not Assigned</span>";
?>
    <div class="subject-card">
        <h3><?= htmlspecialchars($row['subject_name']) ?></h3>

        <p class="teacher">
            <?= $row['faculty_name'] ? $faculty : "Not Assigned" ?>
        </p>
    </div>

<?php 
    }
} else { 
?>
    <p>No subjects found for your course.</p>
<?php 
} 
?>

</div>

<a class="back-btn" href="dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
