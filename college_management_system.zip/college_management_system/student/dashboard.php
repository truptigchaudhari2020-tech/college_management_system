<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
checkRole('student');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Header - Mobile App Style */
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 20px 25px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .header h2 {
            color: #2c3e50;
            font-size: clamp(22px, 5vw, 28px);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
        }

        .header p {
            color: #667eea;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            margin-top: 5px;
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px 20px;
        }

        /* Welcome Banner */
        .welcome-banner {
            background: white;
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
            animation: scaleIn 0.6s ease-out 0.2s both;
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .welcome-banner::before {
            content: '🎓';
            position: absolute;
            font-size: 100px;
            opacity: 0.05;
            right: 20px;
            top: 50%;
            transform: translateY(-50%) rotate(-15deg);
        }

        .welcome-banner h3 {
            color: #2c3e50;
            font-size: clamp(18px, 4vw, 22px);
            margin-bottom: 8px;
        }

        .welcome-banner p {
            color: #666;
            font-size: clamp(13px, 3.5vw, 15px);
        }

        /* Cards Grid */
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        /* Card - Mobile App Style */
        .card {
            background: white;
            border-radius: 20px;
            padding: 30px 25px;
            text-align: center;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            cursor: pointer;
            position: relative;
            overflow: hidden;
            border: 2px solid transparent;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.4s ease;
        }

        .card:hover::before {
            transform: scaleX(1);
        }

        .card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 15px 50px rgba(102, 126, 234, 0.3);
            border-color: rgba(102, 126, 234, 0.2);
        }

        .card a {
            text-decoration: none;
            color: #2c3e50;
            font-weight: 600;
            font-size: clamp(15px, 3.5vw, 17px);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
        }

        .card a::before {
            content: attr(data-icon);
            font-size: 48px;
            display: block;
            animation: bounce 2s ease-in-out infinite;
        }

        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-8px);
            }
        }

        /* Logout Card Special Style */
        .card.logout-card {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            border: none;
        }

        .card.logout-card:hover {
            box-shadow: 0 15px 50px rgba(231, 76, 60, 0.4);
        }

        .card.logout-card a {
            color: white;
        }

        .logout {
            color: white !important;
        }

        /* Staggered Animation for Cards */
        .card {
            animation: fadeInUp 0.5s ease-out both;
        }

        .card:nth-child(1) { animation-delay: 0.1s; }
        .card:nth-child(2) { animation-delay: 0.2s; }
        .card:nth-child(3) { animation-delay: 0.3s; }
        .card:nth-child(4) { animation-delay: 0.4s; }
        .card:nth-child(5) { animation-delay: 0.5s; }
        .card:nth-child(6) { animation-delay: 0.6s; }
        .card:nth-child(7) { animation-delay: 0.7s; }
        .card:nth-child(8) { animation-delay: 0.8s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 18px 20px;
            }

            .container {
                padding: 25px 15px;
            }

            .welcome-banner {
                padding: 20px;
                margin-bottom: 25px;
            }

            .cards {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                gap: 15px;
            }

            .card {
                padding: 25px 20px;
            }

            .card a::before {
                font-size: 40px;
            }
        }

        /* Small Mobile */
        @media (max-width: 400px) {
            .cards {
                grid-template-columns: 1fr;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }

        /* Quick Stats Bar (Optional Enhancement) */
        .stats-bar {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .stat-item {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 20px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            animation: slideRight 0.6s ease-out both;
        }

        .stat-item:nth-child(1) { animation-delay: 0.1s; }
        .stat-item:nth-child(2) { animation-delay: 0.2s; }
        .stat-item:nth-child(3) { animation-delay: 0.3s; }

        @keyframes slideRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .stat-item h4 {
            color: #667eea;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }

        .stat-item p {
            color: #2c3e50;
            font-size: 24px;
            font-weight: 700;
        }
    </style>
</head>
<body>

<div class="header">
    <h2>🎓 Student Dashboard</h2>
    <p>Welcome, <?= htmlspecialchars($_SESSION['name']); ?></p>
</div>

<div class="container">

    <div class="cards">

        <div class="card">
            <a href="profile.php" data-icon="👤">My Profile</a>
        </div>

        <div class="card">
            <a href="view_attendance.php" data-icon="🗓️">Attendance</a>
        </div>

        <div class="card">
            <a href="view_fees.php" data-icon="💰">Fees</a>
        </div>

        <div class="card">
            <a href="view_results.php" data-icon="📊">Results</a>
        </div>

        <div class="card">
            <a href="library.php" data-icon="📚">Library</a>
        </div>

        <div class="card">
            <a href="course.php" data-icon="📘">My Course Subjects</a>
        </div>

        <div class="card">
            <a href="notice.php" data-icon="📢">Notices</a>
        </div>

        <div class="card logout-card">
            <a href="../auth/logout.php" class="logout" data-icon="🚪">Logout</a>
        </div>

    </div>

</div>

</body>
</html>