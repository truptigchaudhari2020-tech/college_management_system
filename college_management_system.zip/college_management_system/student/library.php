<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

$student_id = $_SESSION['user_id'];

/* ISSUED BOOKS WITH RETURN DATE */
$issued = $conn->query("
    SELECT 
        lb.book_name,
        bi.issue_date,
        bi.return_date,
        bi.status
    FROM book_issue bi
    JOIN library_books lb ON bi.book_id = lb.id
    WHERE bi.student_id = $student_id
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Library</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Page Header */
        .page-header {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: slideDown 0.6s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header::before {
            content: '📚';
            position: absolute;
            font-size: 150px;
            opacity: 0.05;
            right: -20px;
            top: 50%;
            transform: translateY(-50%) rotate(-15deg);
        }

        .library-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            animation: bounce 2s ease-in-out infinite;
            position: relative;
            z-index: 1;
        }

        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .page-header h2 {
            color: #2c3e50;
            font-size: clamp(24px, 5vw, 30px);
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            color: #667eea;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 500;
            position: relative;
            z-index: 1;
        }

        /* Books Container */
        .books-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out 0.2s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .books-container::before {
            content: '';
            display: block;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        /* Book Cards Grid */
        .books-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            padding: 30px;
        }

        .book-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 16px;
            padding: 25px;
            border: 2px solid #e0e4e8;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            animation: scaleIn 0.5s ease-out both;
        }

        .book-card:nth-child(1) { animation-delay: 0.1s; }
        .book-card:nth-child(2) { animation-delay: 0.2s; }
        .book-card:nth-child(3) { animation-delay: 0.3s; }
        .book-card:nth-child(4) { animation-delay: 0.4s; }
        .book-card:nth-child(5) { animation-delay: 0.5s; }
        .book-card:nth-child(6) { animation-delay: 0.6s; }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .book-card::before {
            content: '📖';
            position: absolute;
            font-size: 80px;
            opacity: 0.05;
            right: -10px;
            top: 50%;
            transform: translateY(-50%);
        }

        .book-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.2);
            border-color: #667eea;
        }

        .book-title {
            font-size: clamp(16px, 4vw, 18px);
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
            z-index: 1;
        }

        .book-title::before {
            content: '📕';
            font-size: 24px;
        }

        .book-details {
            display: flex;
            flex-direction: column;
            gap: 12px;
            position: relative;
            z-index: 1;
        }

        .detail-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 14px;
            background: white;
            border-radius: 10px;
            font-size: clamp(13px, 3.5vw, 14px);
        }

        .detail-label {
            color: #667eea;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .detail-value {
            color: #2c3e50;
            font-weight: 500;
        }

        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-badge.issued {
            background: linear-gradient(135deg, #fff4e5 0%, #ffe9cc 100%);
            color: #e65100;
            border: 2px solid #ffc107;
        }

        .status-badge.returned {
            background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
            color: #2e7d32;
            border: 2px solid #4caf50;
        }

        .status-badge.overdue {
            background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%);
            color: #c62828;
            border: 2px solid #f44336;
        }

        /* Table View (Alternative Layout) */
        .table-view {
            display: none;
            padding: 30px;
        }

        .table-wrapper {
            overflow-x: auto;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        table th {
            color: white;
            padding: 16px;
            text-align: left;
            font-size: clamp(13px, 3.5vw, 15px);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        table td {
            padding: 14px 16px;
            border-bottom: 1px solid #e0e4e8;
            color: #2c3e50;
            font-size: clamp(13px, 3.5vw, 15px);
        }

        table tbody tr {
            background: white;
            transition: all 0.3s ease;
        }

        table tbody tr:hover {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            transform: scale(1.01);
        }

        table tbody tr:last-child td {
            border-bottom: none;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            animation: fadeIn 0.6s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .empty-icon {
            font-size: 80px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            color: #2c3e50;
            font-size: clamp(18px, 4vw, 22px);
            margin-bottom: 10px;
        }

        .empty-state p {
            color: #666;
            font-size: clamp(14px, 3.5vw, 16px);
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 32px;
            background: white;
            color: #667eea;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-top: 25px;
            animation: fadeIn 0.6s ease-out 0.8s both;
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        .back-btn:active {
            transform: translateY(-1px);
        }

        .back-btn-wrapper {
            text-align: center;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .page-header {
                padding: 25px 20px;
            }

            .library-icon {
                width: 80px;
                height: 80px;
                font-size: 40px;
                margin-bottom: 16px;
            }

            .books-grid {
                grid-template-columns: 1fr;
                padding: 20px;
                gap: 15px;
            }

            .book-card {
                padding: 20px;
            }

            .back-btn {
                width: calc(100% - 40px);
                margin-left: 20px;
                margin-right: 20px;
                justify-content: center;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }
    </style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <div class="library-icon">📚</div>
        <h2>My Issued Books</h2>
        <p>Track your borrowed books and return dates</p>
    </div>

    <div class="books-container">
        <?php if ($issued->num_rows > 0) { ?>
            <div class="books-grid">
                <?php while ($row = $issued->fetch_assoc()) { 
                    // Determine status class
                    $statusClass = strtolower($row['status']);
                    if ($statusClass === 'issued' && strtotime($row['return_date']) < time()) {
                        $statusClass = 'overdue';
                    }
                ?>
                    <div class="book-card">
                        <div class="book-title">
                            <?= htmlspecialchars($row['book_name']) ?>
                        </div>
                        
                        <div class="book-details">
                            <div class="detail-item">
                                <span class="detail-label">📅 Issue Date</span>
                                <span class="detail-value"><?= htmlspecialchars($row['issue_date']) ?></span>
                            </div>
                            
                            <div class="detail-item">
                                <span class="detail-label">🔖 Return Date</span>
                                <span class="detail-value"><?= htmlspecialchars($row['return_date']) ?></span>
                            </div>
                            
                            <div class="detail-item">
                                <span class="detail-label">Status</span>
                                <span class="status-badge <?= $statusClass ?>">
                                    <?= htmlspecialchars($row['status']) ?>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php } else { ?>
            <div class="empty-state">
                <div class="empty-icon">📚</div>
                <h3>No Books Issued</h3>
                <p>You haven't borrowed any books from the library yet.</p>
            </div>
        <?php } ?>
    </div>

    <div class="back-btn-wrapper">
        <a href="dashboard.php" class="back-btn">
            <span>⬅</span>
            <span>Back to Dashboard</span>
        </a>
    </div>

</div>

</body>
</html>