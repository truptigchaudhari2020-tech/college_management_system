<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

$student_id = $_SESSION['user_id'];

$result = $conn->query("
    SELECT subject, exam_type, marks, out_of, grade
    FROM results
    WHERE student_id = $student_id
    ORDER BY exam_type, subject
");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Results</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body { font-family: Arial; background:#f4f6f8; }
table { width:90%; border-collapse:collapse; margin:auto; }
th, td { padding:10px; border:1px solid #ccc; text-align:center; }
th { background:#ddd; }
.pass { background:#d4ffd4; }       /* Green */
.medium { background:#fff4c2; }     /* Yellow */
.fail { background:#ffd4d4; }       /* Red */
.box { background:white; padding:15px; margin:20px; border-radius:8px; }
</style>
</head>

<body>

<h2 style="text-align:center;">📘 My Exam Results</h2>

<div class="box">

<table>
<tr>
    <th>Exam Type</th>
    <th>Subject</th>
    <th>Marks</th>
    <th>Out Of</th>
    <th>Percentage</th>
    <th>Grade</th>
</tr>

<?php 
$chartLabels = [];
$chartPercent = [];

while ($row = $result->fetch_assoc()) { 

    $percent = ($row['marks'] / $row['out_of']) * 100;

    // Store for chart
    $chartLabels[] = $row['subject'] . " (" . $row['exam_type'] . ")";
    $chartPercent[] = round($percent);

    // Color Class
    if ($percent >= 75) $class = "pass";
    elseif ($percent >= 40) $class = "medium";
    else $class = "fail";
?>
<tr class="<?= $class ?>">
    <td><?= $row['exam_type'] ?></td>
    <td><?= $row['subject'] ?></td>
    <td><?= $row['marks'] ?></td>
    <td><?= $row['out_of'] ?></td>
    <td><?= round($percent) ?>%</td>
    <td><?= $row['grade'] ?></td>
</tr>
<?php } ?>
</table>

</div>


<!-- RESULT PERFORMANCE CHART -->
<div class="box">
<h3 style="text-align:center;">📊 Performance Chart</h3>

<canvas id="resultChart"></canvas>

<script>
let labels = <?= json_encode($chartLabels) ?>;
let data = <?= json_encode($chartPercent) ?>;

new Chart(document.getElementById("resultChart"), {
    type: "bar",
    data: {
        labels: labels,
        datasets: [{
            label: "Percentage",
            data: data,
            backgroundColor: "#4dabf7"
        }]
    },
    options: {
        scales: { y: { beginAtZero: true, max: 100 } }
    }
});
</script>
</div>

<div style="text-align:center;">
    <a href="dashboard.php">⬅ Back</a>
</div>

</body>
</html>
