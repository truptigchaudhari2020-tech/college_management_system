<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('student');

$student_id = $_SESSION['user_id'];

/* Fetch student category */
$stu = $conn->query("
    SELECT caste_category 
    FROM users 
    WHERE id=$student_id
")->fetch_assoc();

$category = $stu['caste_category'];

/* Fetch total fee for that category */
$total_fee_row = $conn->query("
    SELECT total_fee 
    FROM fee_structure 
    WHERE caste_category='$category'
")->fetch_assoc();

$total_fee = $total_fee_row['total_fee'];

/* Fetch paid amount */
$paid_row = $conn->query("
    SELECT SUM(amount) AS paid 
    FROM fees 
    WHERE student_id=$student_id
")->fetch_assoc();

$paid = $paid_row['paid'] ?? 0;

/* Calculate remaining fee */
$remaining = $total_fee - $paid;

/* Fetch payment history */
$history = $conn->query("
    SELECT fee_type, amount, status, payment_date
    FROM fees
    WHERE student_id = $student_id
    ORDER BY payment_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Fees</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Page Header */
        .page-header {
            background: white;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            text-align: center;
            animation: slideDown 0.6s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header h2 {
            color: #2c3e50;
            font-size: clamp(22px, 5vw, 28px);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-weight: 700;
        }

        /* Box - Card Style */
        .box {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out both;
        }

        .box:nth-child(2) { animation-delay: 0.1s; }
        .box:nth-child(3) { animation-delay: 0.2s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .box h3 {
            color: #2c3e50;
            font-size: clamp(20px, 4.5vw, 24px);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Fee Summary Grid */
        .fee-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 20px;
            border-radius: 16px;
            border: 2px solid #e0e4e8;
            text-align: center;
            animation: scaleIn 0.5s ease-out both;
        }

        .summary-item:nth-child(1) { animation-delay: 0.2s; }
        .summary-item:nth-child(2) { animation-delay: 0.3s; }
        .summary-item:nth-child(3) { animation-delay: 0.4s; }
        .summary-item:nth-child(4) { animation-delay: 0.5s; }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .summary-item b {
            display: block;
            color: #667eea;
            font-size: clamp(12px, 3vw, 14px);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }

        .summary-item p {
            color: #2c3e50;
            font-size: clamp(22px, 5vw, 28px);
            font-weight: 700;
            margin: 0;
        }

        .summary-item.remaining {
            background: linear-gradient(135deg, #fff4e5 0%, #ffe9cc 100%);
            border-color: #ffc107;
        }

        .summary-item.paid {
            background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
            border-color: #4caf50;
        }

        /* Chart Container */
        .chart-container {
            max-width: 400px;
            margin: 30px auto;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 16px;
            animation: fadeIn 0.8s ease-out 0.6s both;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        canvas {
            max-height: 300px;
        }

        /* Table Styling */
        .table-wrapper {
            overflow-x: auto;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        table th {
            color: white;
            padding: 16px;
            text-align: left;
            font-size: clamp(13px, 3.5vw, 15px);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        table td {
            padding: 14px 16px;
            border-bottom: 1px solid #e0e4e8;
            color: #2c3e50;
            font-size: clamp(13px, 3.5vw, 15px);
        }

        table tbody tr {
            background: white;
            transition: all 0.3s ease;
        }

        table tbody tr:hover {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            transform: scale(1.01);
        }

        table tbody tr:last-child td {
            border-bottom: none;
        }

        /* Status Badge */
        table td:last-child {
            font-weight: 600;
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 32px;
            background: white;
            color: #667eea;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-top: 25px;
            animation: fadeIn 0.6s ease-out 0.8s both;
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        .back-btn:active {
            transform: translateY(-1px);
        }

        .back-btn-wrapper {
            text-align: center;
        }

        /* Progress Bar */
        .progress-bar {
            height: 30px;
            background: #e0e4e8;
            border-radius: 15px;
            overflow: hidden;
            margin: 20px 0;
            position: relative;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4caf50 0%, #81c784 100%);
            border-radius: 15px;
            transition: width 1s ease-out;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding-right: 15px;
            color: white;
            font-weight: 700;
            font-size: 14px;
            animation: fillProgress 1.5s ease-out 0.5s both;
        }

        @keyframes fillProgress {
            from {
                width: 0;
            }
            to {
                width: <?= $total_fee > 0 ? ($paid / $total_fee) * 100 : 0 ?>%;
            }
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .page-header {
                padding: 20px;
            }

            .box {
                padding: 25px 20px;
            }

            .fee-summary {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }

            .chart-container {
                max-width: 100%;
                padding: 20px;
            }

            table th,
            table td {
                padding: 12px 10px;
                font-size: 13px;
            }

            .back-btn {
                width: calc(100% - 40px);
                margin-left: 20px;
                margin-right: 20px;
                justify-content: center;
            }
        }

        @media (max-width: 400px) {
            .fee-summary {
                grid-template-columns: 1fr;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }

        .empty-state-icon {
            font-size: 60px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
    </style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <h2>💰 My Fee Details</h2>
    </div>

    <!-- OVERVIEW BOX -->
    <div class="box">
        <h3>📌 Fee Summary</h3>

        <div class="fee-summary">
            <div class="summary-item">
                <b>Category</b>
                <p><?= htmlspecialchars($category) ?></p>
            </div>

            <div class="summary-item">
                <b>Total Fee</b>
                <p>₹<?= number_format($total_fee) ?></p>
            </div>

            <div class="summary-item paid">
                <b>Total Paid</b>
                <p>₹<?= number_format($paid) ?></p>
            </div>

            <div class="summary-item remaining">
                <b>Remaining</b>
                <p>₹<?= number_format($remaining) ?></p>
            </div>
        </div>

        <div class="progress-bar">
            <div class="progress-fill">
                <?= $total_fee > 0 ? round(($paid / $total_fee) * 100) : 0 ?>%
            </div>
        </div>

        <div class="chart-container">
            <canvas id="feeChart"></canvas>
        </div>

        <script>
        new Chart(document.getElementById("feeChart"), {
            type: "pie",
            data: {
                labels: ["Paid", "Remaining"],
                datasets: [{
                    data: [<?= $paid ?>, <?= $remaining ?>],
                    backgroundColor: ["#4caf50", "#f44336"]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            font: {
                                size: 14
                            }
                        }
                    }
                }
            }
        });
        </script>
    </div>

    <!-- PAYMENT HISTORY -->
    <div class="box">
        <h3>📄 Payment History</h3>

        <?php if ($history->num_rows > 0) { ?>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Fee Type</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $history->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['payment_date']) ?></td>
                            <td><?= htmlspecialchars($row['fee_type']) ?></td>
                            <td>₹<?= number_format($row['amount']) ?></td>
                            <td><?= htmlspecialchars($row['status']) ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        <?php } else { ?>
            <div class="empty-state">
                <div class="empty-state-icon">📭</div>
                <p>No payment history available yet.</p>
            </div>
        <?php } ?>
    </div>

    <div class="back-btn-wrapper">
        <a href="dashboard.php" class="back-btn">
            <span>⬅</span>
            <span>Back to Dashboard</span>
        </a>
    </div>

</div>

</body>
</html>