<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

$faculty_id = $_SESSION['user_id'];

/* FACULTY INFO */
$faculty = $conn->query("
    SELECT full_name, qualification, courses 
    FROM users 
    WHERE id = $faculty_id
")->fetch_assoc();

/* ASSIGNED SUBJECTS */
$subjects = $conn->query("
    SELECT fs.subject_id, s.subject_name, s.course
    FROM faculty_subjects fs
    JOIN subjects s ON s.id = fs.subject_id
    WHERE fs.faculty_id = $faculty_id
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Header - Mobile App Style */
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 20px 25px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .header h2 {
            color: #2c3e50;
            font-size: clamp(22px, 5vw, 28px);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
        }

        .header p {
            color: #667eea;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            margin-top: 5px;
        }

        /* Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px 20px;
        }

        /* Profile Box */
        .box {
            background: white;
            padding: 30px;
            margin-bottom: 25px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out both;
        }

        .box:nth-child(1) { animation-delay: 0.1s; }
        .box:nth-child(2) { animation-delay: 0.2s; }
        .box:nth-child(3) { animation-delay: 0.3s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .box h3 {
            color: #2c3e50;
            font-size: clamp(20px, 4.5vw, 24px);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .box p {
            color: #555;
            font-size: clamp(14px, 3.5vw, 16px);
            margin: 12px 0;
            line-height: 1.6;
        }

        .box p b {
            color: #667eea;
            font-weight: 600;
        }

        .box hr {
            border: none;
            height: 2px;
            background: linear-gradient(90deg, transparent, #e0e4e8, transparent);
            margin: 20px 0;
        }

        /* Subject Cards Grid */
        .subjects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .subject-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border: 2px solid #e0e4e8;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            animation: scaleIn 0.5s ease-out both;
        }

        .subject-card:nth-child(1) { animation-delay: 0.1s; }
        .subject-card:nth-child(2) { animation-delay: 0.2s; }
        .subject-card:nth-child(3) { animation-delay: 0.3s; }
        .subject-card:nth-child(4) { animation-delay: 0.4s; }
        .subject-card:nth-child(5) { animation-delay: 0.5s; }
        .subject-card:nth-child(6) { animation-delay: 0.6s; }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .subject-card::before {
            content: '📖';
            position: absolute;
            font-size: 80px;
            opacity: 0.05;
            right: -10px;
            top: 50%;
            transform: translateY(-50%);
        }

        .subject-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.3);
            border-color: #667eea;
        }

        .subject-card h3 {
            color: #2c3e50;
            font-size: clamp(18px, 4vw, 20px);
            margin-bottom: 12px;
            position: relative;
            z-index: 1;
        }

        .subject-card p {
            color: #666;
            font-size: clamp(13px, 3.5vw, 15px);
            margin: 8px 0;
            position: relative;
            z-index: 1;
        }

        .count {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            margin: 12px 0;
            font-weight: 600;
            font-size: 14px;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
            position: relative;
            z-index: 1;
        }

        .btn {
            display: block;
            padding: 12px;
            margin: 8px 0;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            border-radius: 10px;
            text-decoration: none;
            text-align: center;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            position: relative;
            z-index: 1;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: left 0.5s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(44, 62, 80, 0.4);
        }

        .btn:active {
            transform: translateY(0);
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .quick-action-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 20px;
            border-radius: 14px;
            border: 2px solid #e0e4e8;
            transition: all 0.3s ease;
            animation: slideRight 0.5s ease-out both;
        }

        .quick-action-card:nth-child(1) { animation-delay: 0.1s; }
        .quick-action-card:nth-child(2) { animation-delay: 0.2s; }
        .quick-action-card:nth-child(3) { animation-delay: 0.3s; }

        @keyframes slideRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .quick-action-card:hover {
            transform: translateX(5px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.2);
            border-color: #667eea;
        }

        .quick-action-card a {
            color: #2c3e50;
            text-decoration: none;
            font-weight: 600;
            font-size: clamp(14px, 3.5vw, 16px);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }

        .empty-icon {
            font-size: 60px;
            margin-bottom: 15px;
            opacity: 0.5;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 18px 20px;
            }

            .container {
                padding: 25px 15px;
            }

            .box {
                padding: 25px 20px;
            }

            .subjects-grid {
                grid-template-columns: 1fr;
            }

            .subject-card {
                padding: 20px;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }

        /* Profile Info Grid */
        .profile-info {
            display: grid;
            gap: 15px;
        }

        .info-item {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 16px 20px;
            border-radius: 12px;
            border-left: 4px solid #667eea;
        }
    </style>
</head>
<body>

<div class="header">
    <h2>👨‍🏫 Faculty Dashboard</h2>
    <p>Welcome, <?= htmlspecialchars($faculty['full_name']) ?></p>
</div>

<div class="container">

    <!-- PROFILE BOX -->
    <div class="box">
        <h3>👤 My Profile</h3>
        <div class="profile-info">
            <div class="info-item">
                <p><b>Qualification:</b> <?= htmlspecialchars($faculty['qualification']) ?></p>
            </div>
            <div class="info-item">
                <p><b>Courses Teaching:</b> <?= htmlspecialchars($faculty['courses']) ?></p>
            </div>
        </div>
    </div>

    <!-- SUBJECT CARDS -->
    <div class="box">
        <h3>📚 My Assigned Subjects</h3>
        <hr>

        <?php if ($subjects->num_rows > 0) { ?>
            <div class="subjects-grid">
                <?php while ($s = $subjects->fetch_assoc()) { 

                    // Count students in that course
                    $count = $conn->query("
                        SELECT COUNT(*) AS total
                        FROM users
                        WHERE role='student' AND course='{$s['course']}'
                    ")->fetch_assoc()['total'];
                ?>
                    <div class="subject-card">
                        <h3><?= htmlspecialchars($s['subject_name']) ?></h3>
                        <p><b>Course:</b> <?= htmlspecialchars($s['course']) ?></p>
                        <span class="count">👥 <?= $count ?> Students</span>

                        <a class="btn" href="view_students.php?subject_id=<?= $s['subject_id'] ?>">
                            👁️ View Students
                        </a>

                        <a class="btn" href="take_attendance.php?subject_id=<?= $s['subject_id'] ?>">
                            ✅ Take Attendance
                        </a>

                        <a class="btn" href="upload_results.php?subject_id=<?= $s['subject_id'] ?>">
                            📊 Upload Results
                        </a>
                    </div>
                <?php } ?>
            </div>
        <?php } else { ?>
            <div class="empty-state">
                <div class="empty-icon">📚</div>
                <p>No subjects assigned yet.</p>
            </div>
        <?php } ?>
    </div>

    <!-- QUICK ACTIONS -->
    <div class="box">
        <h3>⚡ Quick Actions</h3>
        <div class="quick-actions">
            <div class="quick-action-card">
                <a href="faculty_subjects.php">
                    <span>📘</span>
                    <span>My Subjects</span>
                </a>
            </div>
            <div class="quick-action-card">
                <a href="profile.php">
                    <span>👤</span>
                    <span>View Profile</span>
                </a>
            </div>
            <div class="quick-action-card">
                <a href="../auth/logout.php">
                    <span>🚪</span>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </div>

</div>

</body>
</html>