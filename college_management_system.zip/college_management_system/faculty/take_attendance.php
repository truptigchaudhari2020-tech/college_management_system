<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

if (!isset($_GET['subject_id'])) die("Invalid request!");

$faculty_id = $_SESSION['user_id'];
$subject_id = $_GET['subject_id'];

// Fetch subject details
$subject = $conn->query("
    SELECT subject_name, course
    FROM subjects
    WHERE id=$subject_id
")->fetch_assoc();

$course = $subject['course'];

$students = $conn->query("
    SELECT id, full_name
    FROM users
    WHERE role='student' AND course='$course'
");

$msg = "";

// SAVE ATTENDANCE
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    foreach ($_POST['status'] as $student_id => $status) {
        $stmt = $conn->prepare("
            INSERT INTO attendance 
            (student_id, faculty_id, course, subject, attendance_date, status)
            VALUES (?, ?, ?, ?, CURDATE(), ?)
        ");
        $stmt->bind_param(
            "iisss",
            $student_id,
            $faculty_id,
            $course,
            $subject['subject_name'],
            $status
        );
        $stmt->execute();
    }

    $msg = "Attendance saved successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Attendance</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Container */
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        /* Page Header */
        .page-header {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            text-align: center;
            animation: slideDown 0.6s ease-out;
            position: relative;
            overflow: hidden;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header::before {
            content: '✅';
            position: absolute;
            font-size: 150px;
            opacity: 0.05;
            right: -20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .attendance-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            animation: bounce 2s ease-in-out infinite;
            position: relative;
            z-index: 1;
        }

        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .page-header h2 {
            color: #2c3e50;
            font-size: clamp(20px, 5vw, 26px);
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            color: #667eea;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            position: relative;
            z-index: 1;
        }

        .course-badge {
            display: inline-block;
            padding: 6px 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
            margin-top: 8px;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        /* Success Message */
        .success-message {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 600;
            text-align: center;
            border: 2px solid #b1dfbb;
            animation: slideDown 0.5s ease-out;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .success-message::before {
            content: '✓';
            width: 30px;
            height: 30px;
            background: #28a745;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        /* Form Container */
        .form-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out 0.2s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-container::before {
            content: '';
            display: block;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        /* Table Styling */
        .table-wrapper {
            padding: 30px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        table th {
            color: white;
            padding: 16px;
            text-align: left;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        table td {
            padding: 16px;
            border-bottom: 1px solid #e0e4e8;
            color: #2c3e50;
            font-size: clamp(14px, 3.5vw, 16px);
        }

        table tbody tr {
            background: white;
            transition: all 0.3s ease;
            animation: fadeIn 0.5s ease-out both;
        }

        table tbody tr:nth-child(1) { animation-delay: 0.1s; }
        table tbody tr:nth-child(2) { animation-delay: 0.15s; }
        table tbody tr:nth-child(3) { animation-delay: 0.2s; }
        table tbody tr:nth-child(4) { animation-delay: 0.25s; }
        table tbody tr:nth-child(5) { animation-delay: 0.3s; }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        table tbody tr:hover {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
        }

        table tbody tr:last-child td {
            border-bottom: none;
        }

        /* Custom Select Dropdown */
        select {
            width: 100%;
            padding: 10px 16px;
            border: 2px solid #e0e4e8;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            background: #f8f9fa;
            color: #2c3e50;
            cursor: pointer;
            transition: all 0.3s ease;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23667eea' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 35px;
        }

        select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        select option.present {
            color: #28a745;
            font-weight: 600;
        }

        select option.absent {
            color: #dc3545;
            font-weight: 600;
        }

        /* Submit Button */
        .submit-btn {
            width: calc(100% - 60px);
            margin: 0 30px 30px;
            padding: 16px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 8px 20px rgba(40, 167, 69, 0.3);
            position: relative;
            overflow: hidden;
        }

        .submit-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: left 0.5s ease;
        }

        .submit-btn:hover::before {
            left: 100%;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(40, 167, 69, 0.4);
        }

        .submit-btn:active {
            transform: translateY(-1px);
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 32px;
            background: white;
            color: #667eea;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-top: 20px;
            animation: fadeIn 0.6s ease-out 0.5s both;
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        .back-btn-wrapper {
            text-align: center;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .page-header {
                padding: 25px 20px;
            }

            .attendance-icon {
                width: 70px;
                height: 70px;
                font-size: 35px;
            }

            .table-wrapper {
                padding: 20px;
            }

            table th,
            table td {
                padding: 12px 10px;
                font-size: 14px;
            }

            select {
                padding: 10px 12px;
                font-size: 14px;
            }

            .submit-btn {
                width: calc(100% - 40px);
                margin: 0 20px 20px;
            }

            .back-btn {
                width: calc(100% - 40px);
                margin-left: 20px;
                margin-right: 20px;
                justify-content: center;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }

        /* Quick Actions Bar */
        .quick-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .quick-btn {
            padding: 10px 20px;
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .quick-btn:hover {
            background: #667eea;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <div class="attendance-icon">✅</div>
        <h2>Attendance → <?= htmlspecialchars($subject['subject_name']) ?></h2>
        <p><span class="course-badge"><?= htmlspecialchars($course) ?></span></p>
    </div>

    <?php if ($msg): ?>
        <div class="success-message">
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-container">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Student Name</th>
                            <th>Attendance Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($stu = $students->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($stu['full_name']) ?></td>
                            <td>
                                <select name="status[<?= $stu['id'] ?>]" required>
                                    <option value="Present" class="present">✓ Present</option>
                                    <option value="Absent" class="absent">✗ Absent</option>
                                </select>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <button type="submit" class="submit-btn">
                💾 Save Attendance
            </button>
        </div>
    </form>

    <div class="back-btn-wrapper">
        <a href="faculty_subjects.php" class="back-btn">
            <span>⬅</span>
            <span>Back to Subjects</span>
        </a>
    </div>

</div>

</body>
</html>