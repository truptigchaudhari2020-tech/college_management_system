<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

if (!isset($_GET['subject_id'])) die("Invalid request!");

$subject_id = $_GET['subject_id'];

// Fetch subject info
$subject = $conn->query("
    SELECT subject_name, course
    FROM subjects 
    WHERE id=$subject_id
")->fetch_assoc();

$course = $subject['course'];

// Fetch students of that course
$students = $conn->query("
    SELECT id, full_name, email
    FROM users
    WHERE role='student' AND course='$course'
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Enrolled</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Container */
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        /* Page Header */
        .page-header {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            text-align: center;
            animation: slideDown 0.6s ease-out;
            position: relative;
            overflow: hidden;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header::before {
            content: '👥';
            position: absolute;
            font-size: 150px;
            opacity: 0.05;
            right: -20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .students-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            animation: bounce 2s ease-in-out infinite;
            position: relative;
            z-index: 1;
        }

        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .page-header h2 {
            color: #2c3e50;
            font-size: clamp(20px, 5vw, 26px);
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            color: #667eea;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            position: relative;
            z-index: 1;
        }

        .course-badge {
            display: inline-block;
            padding: 6px 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
            margin-top: 8px;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        /* Students Count Badge */
        .count-badge {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 10px 20px;
            border-radius: 12px;
            display: inline-block;
            margin-bottom: 20px;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
            animation: fadeIn 0.6s ease-out 0.3s both;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        /* Students Container */
        .students-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out 0.2s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .students-container::before {
            content: '';
            display: block;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        /* Table Styling */
        .table-wrapper {
            padding: 30px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        table th {
            color: white;
            padding: 16px;
            text-align: left;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        table td {
            padding: 16px;
            border-bottom: 1px solid #e0e4e8;
            color: #2c3e50;
            font-size: clamp(14px, 3.5vw, 16px);
        }

        table tbody tr {
            background: white;
            transition: all 0.3s ease;
            animation: slideRight 0.5s ease-out both;
        }

        table tbody tr:nth-child(1) { animation-delay: 0.1s; }
        table tbody tr:nth-child(2) { animation-delay: 0.15s; }
        table tbody tr:nth-child(3) { animation-delay: 0.2s; }
        table tbody tr:nth-child(4) { animation-delay: 0.25s; }
        table tbody tr:nth-child(5) { animation-delay: 0.3s; }
        table tbody tr:nth-child(6) { animation-delay: 0.35s; }
        table tbody tr:nth-child(7) { animation-delay: 0.4s; }
        table tbody tr:nth-child(8) { animation-delay: 0.45s; }

        @keyframes slideRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        table tbody tr:hover {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            transform: scale(1.01);
        }

        table tbody tr:last-child td {
            border-bottom: none;
        }

        /* Student Name with Icon */
        table td:first-child {
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        table td:first-child::before {
            content: '👤';
            font-size: 20px;
        }

        /* Email Link Styling */
        table td a {
            color: #667eea;
            text-decoration: none;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        table td a::before {
            content: '📧';
            font-size: 16px;
        }

        table td a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }

        .empty-icon {
            font-size: 80px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            color: #2c3e50;
            font-size: clamp(18px, 4vw, 22px);
            margin-bottom: 10px;
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 32px;
            background: white;
            color: #667eea;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-top: 25px;
            animation: fadeIn 0.6s ease-out 0.5s both;
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        .back-btn-wrapper {
            text-align: center;
        }

        /* Search Bar (Optional Enhancement) */
        .search-bar {
            padding: 0 30px 20px;
        }

        .search-input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid #e0e4e8;
            border-radius: 12px;
            font-size: 15px;
            background: #f8f9fa url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='%23667eea' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'%3E%3C/circle%3E%3Cpath d='m21 21-4.35-4.35'%3E%3C/path%3E%3C/svg%3E") no-repeat 15px center;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            outline: none;
            border-color: #667eea;
            background-color: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .page-header {
                padding: 25px 20px;
            }

            .students-icon {
                width: 70px;
                height: 70px;
                font-size: 35px;
            }

            .table-wrapper {
                padding: 20px;
            }

            table th,
            table td {
                padding: 12px 10px;
                font-size: 14px;
            }

            table td:first-child::before {
                font-size: 16px;
            }

            .back-btn {
                width: calc(100% - 40px);
                margin-left: 20px;
                margin-right: 20px;
                justify-content: center;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }

        /* Student Count */
        .student-count {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <div class="students-icon">👥</div>
        <h2>Students for <?= htmlspecialchars($subject['subject_name']) ?></h2>
        <p><span class="course-badge"><?= htmlspecialchars($course) ?></span></p>
    </div>

    <div class="student-count">
        <div class="count-badge">
            📊 Total Students: <?= $students->num_rows ?>
        </div>
    </div>

    <div class="students-container">
        <?php if ($students->num_rows > 0) { ?>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Student Name</th>
                            <th>Email Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($stu = $students->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($stu['full_name']) ?></td>
                            <td>
                                <a href="mailto:<?= htmlspecialchars($stu['email']) ?>">
                                    <?= htmlspecialchars($stu['email']) ?>
                                </a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        <?php } else { ?>
            <div class="empty-state">
                <div class="empty-icon">👥</div>
                <h3>No Students Enrolled</h3>
                <p>No students are currently enrolled in this course.</p>
            </div>
        <?php } ?>
    </div>

    <div class="back-btn-wrapper">
        <a href="faculty_subjects.php" class="back-btn">
            <span>⬅</span>
            <span>Back to Subjects</span>
        </a>
    </div>

</div>

</body>
</html>