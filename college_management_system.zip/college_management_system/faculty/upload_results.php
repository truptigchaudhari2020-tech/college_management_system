<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

$faculty_id = $_SESSION['user_id'];

/* FACULTY SUBJECTS */
$subjects = $conn->query("
    SELECT fs.subject_id, s.subject_name, s.course
    FROM faculty_subjects fs
    JOIN subjects s ON s.id = fs.subject_id
    WHERE fs.faculty_id = $faculty_id
");

$selected_subject = $_POST['subject_id'] ?? null;

$students = null;
$subject_info = null;

if ($selected_subject) {
    $subject_info = $conn->query("
        SELECT subject_name, course 
        FROM subjects 
        WHERE id = $selected_subject
    ")->fetch_assoc();

    $students = $conn->query("
        SELECT id, full_name 
        FROM users 
        WHERE role='student' AND course='{$subject_info['course']}'
    ");
}

/* UPLOAD RESULT */
if (isset($_POST['upload_result'])) {
    $student_id = $_POST['student_id'];
    $marks = (int)$_POST['marks'];
    $out_of = (int)$_POST['out_of'];
    $exam_type = $_POST['exam_type'];

    $percentage = ($marks / $out_of) * 100;

    if ($percentage >= 75) $grade = 'A';
    elseif ($percentage >= 60) $grade = 'B';
    elseif ($percentage >= 40) $grade = 'C';
    else $grade = 'F';

    $stmt = $conn->prepare("
        INSERT INTO results 
        (student_id, course, subject, exam_type, marks, out_of, grade)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "isssiis",
        $student_id,
        $subject_info['course'],
        $subject_info['subject_name'],
        $exam_type,
        $marks,
        $out_of,
        $grade
    );
    $stmt->execute();

    echo "<script>alert('Result uploaded successfully');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Upload Results</title>
</head>
<body>

<h2>📊 Upload Results</h2>

<!-- SUBJECT SELECT -->
<form method="POST">
<select name="subject_id" required>
    <option value="">Select Subject</option>
    <?php while ($s = $subjects->fetch_assoc()) { ?>
        <option value="<?= $s['subject_id'] ?>"
            <?= ($selected_subject == $s['subject_id']) ? 'selected' : '' ?>>
            <?= $s['subject_name'] ?> (<?= $s['course'] ?>)
        </option>
    <?php } ?>
</select>
<button>Select</button>
</form>

<hr>

<?php if ($students) { ?>

<h3>Subject: <?= $subject_info['subject_name'] ?> (<?= $subject_info['course'] ?>)</h3>

<form method="POST">
<input type="hidden" name="subject_id" value="<?= $selected_subject ?>">

<!-- STUDENT SELECT -->
<select name="student_id" required>
    <?php while ($stu = $students->fetch_assoc()) { ?>
        <option value="<?= $stu['id'] ?>">
            <?= $stu['full_name'] ?>
        </option>
    <?php } ?>
</select><br><br>

<!-- EXAM TYPE -->
<select name="exam_type" required>
    <option value="">Select Exam Type</option>
    <option>Unit Test 1</option>
    <option>Unit Test 2</option>
    <option>Mid-Sem</option>
    <option>Final-Sem</option>
    <option>Practical</option>
    <option>Viva</option>
    <option>Internal Assessment</option>
</select><br><br>

<!-- MARKS -->
<input type="number" name="marks" min="0" placeholder="Marks Obtained" required><br><br>

<input type="number" name="out_of" min="1" placeholder="Out of Marks (e.g., 20, 50, 100)" required><br><br>

<button name="upload_result">Upload Result</button>
</form>

<?php } ?>

<a href="dashboard.php">⬅ Back</a>

</body>
</html>
