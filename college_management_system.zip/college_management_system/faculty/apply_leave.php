<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
checkRole('faculty');
?>

<!DOCTYPE html>
<html>
<head><title>Apply Leave</title></head>
<body>

<h2>Apply for Leave</h2>

<form>
<input type="date" required><br><br>
<textarea placeholder="Reason" required></textarea><br><br>
<button>Apply</button>
</form>

<p>(Leave module demo – can be extended)</p>

<a href="dashboard.php">⬅ Back</a>

</body>
</html>
