<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

$id = $_SESSION['user_id'];

$data = $conn->query("
    SELECT course, subject FROM faculty_subjects WHERE faculty_id=$id
")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head><title>Assigned Course</title></head>
<body>

<h2>My Assigned Course</h2>

<table border="1" cellpadding="10">
<tr><th>Course</th><td><?= $data['course'] ?></td></tr>
<tr><th>Subject</th><td><?= $data['subject'] ?></td></tr>
</table>

<a href="dashboard.php">⬅ Back</a>

</body>
</html>
