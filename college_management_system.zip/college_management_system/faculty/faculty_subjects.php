<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

$faculty_id = $_SESSION['user_id'];

// Get all subjects assigned to this faculty
$subjects = $conn->query("
    SELECT fs.subject_id, fs.subject, fs.course, s.subject_name
    FROM faculty_subjects fs
    JOIN subjects s ON s.id = fs.subject_id
    WHERE fs.faculty_id = $faculty_id
");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Subjects</title>
<style>
    body { font-family: Arial; padding: 20px; }
    .subject-card {
        display: inline-block;
        width: 260px;
        padding: 15px;
        margin: 10px;
        border-radius: 10px;
        border: 1px solid #ccc;
        background: #f8f8f8;
        box-shadow: 0px 0px 5px #ccc;
        text-align: center;
    }
    .subject-card h3 {
        margin: 0;
        color: #222;
    }
    .btn {
        display: inline-block;
        padding: 7px 12px;
        margin-top: 10px;
        background: black;
        color: white;
        border-radius: 5px;
        text-decoration: none;
    }
</style>
</head>
<body>

<h2>📚 My Assigned Subjects</h2>
<hr>

<?php while ($s = $subjects->fetch_assoc()) { 
    
    // Fetch student count for this course
    $count = $conn->query("
        SELECT COUNT(*) AS total
        FROM users
        WHERE role='student' AND course='{$s['course']}'
    ")->fetch_assoc()['total'];
?>
<div class="subject-card">
    <h3><?= $s['subject_name'] ?></h3>
    <p><b>Course:</b> <?= $s['course'] ?></p>
    <p><b>Students:</b> <?= $count ?></p>

    <a class="btn" href="view_students.php?subject_id=<?= $s['subject_id'] ?>">View Students</a>
    <a class="btn" href="take_attendance.php?subject_id=<?= $s['subject_id'] ?>">Take Attendance</a>
</div>
<?php } ?>

<br><br>
<a href="dashboard.php">⬅ Back</a>

</body>
</html>
