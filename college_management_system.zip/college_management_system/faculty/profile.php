<?php
require_once "../config/session.php";
require_once "../config/auth_check.php";
require_once "../config/db.php";
checkRole('faculty');

$faculty_id = $_SESSION['user_id'];

/* FETCH FACULTY BASIC DETAILS */
$faculty = $conn->query("
    SELECT full_name, email, mobile, qualification, courses
    FROM users
    WHERE id = $faculty_id AND role = 'faculty'
")->fetch_assoc();

/* FETCH ASSIGNED SUBJECTS */
$subjects = $conn->query("
    SELECT s.subject_name, s.course
    FROM faculty_subjects fs
    JOIN subjects s ON s.id = fs.subject_id
    WHERE fs.faculty_id = $faculty_id
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Profile</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Container */
        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        /* Header */
        .page-header {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            text-align: center;
            animation: slideDown 0.6s ease-out;
            position: relative;
            overflow: hidden;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header::before {
            content: '👨‍🏫';
            position: absolute;
            font-size: 150px;
            opacity: 0.05;
            right: -20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .profile-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            animation: bounce 2s ease-in-out infinite;
            position: relative;
            z-index: 1;
        }

        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .page-header h2 {
            color: #2c3e50;
            font-size: clamp(24px, 5vw, 30px);
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            color: #667eea;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 600;
            position: relative;
            z-index: 1;
        }

        /* Box - Card Style */
        .box {
            background: white;
            padding: 30px;
            margin-bottom: 25px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out both;
        }

        .box:nth-child(2) { animation-delay: 0.2s; }
        .box:nth-child(3) { animation-delay: 0.3s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .box h3 {
            color: #2c3e50;
            font-size: clamp(20px, 4.5vw, 24px);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Info Grid */
        .info-grid {
            display: grid;
            gap: 16px;
        }

        .info-row {
            display: grid;
            grid-template-columns: 160px 1fr;
            gap: 20px;
            padding: 16px 0;
            border-bottom: 2px solid #f0f2f5;
            animation: slideRight 0.5s ease-out both;
        }

        .info-row:nth-child(1) { animation-delay: 0.3s; }
        .info-row:nth-child(2) { animation-delay: 0.4s; }
        .info-row:nth-child(3) { animation-delay: 0.5s; }
        .info-row:nth-child(4) { animation-delay: 0.6s; }
        .info-row:nth-child(5) { animation-delay: 0.7s; }

        @keyframes slideRight {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .info-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }

        .info-label {
            font-weight: 600;
            color: #667eea;
            font-size: clamp(13px, 3.5vw, 15px);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-label::before {
            content: attr(data-icon);
            font-size: 20px;
        }

        .info-value {
            color: #2c3e50;
            font-size: clamp(14px, 3.5vw, 16px);
            font-weight: 500;
            display: flex;
            align-items: center;
            padding: 12px 18px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            border: 2px solid #e0e4e8;
        }

        /* Table Styling */
        .table-wrapper {
            overflow-x: auto;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        table th {
            color: white;
            padding: 16px;
            text-align: left;
            font-size: clamp(13px, 3.5vw, 15px);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        table td {
            padding: 14px 16px;
            border-bottom: 1px solid #e0e4e8;
            color: #2c3e50;
            font-size: clamp(13px, 3.5vw, 15px);
        }

        table tbody tr {
            background: white;
            transition: all 0.3s ease;
            animation: fadeIn 0.5s ease-out both;
        }

        table tbody tr:nth-child(1) { animation-delay: 0.1s; }
        table tbody tr:nth-child(2) { animation-delay: 0.2s; }
        table tbody tr:nth-child(3) { animation-delay: 0.3s; }
        table tbody tr:nth-child(4) { animation-delay: 0.4s; }
        table tbody tr:nth-child(5) { animation-delay: 0.5s; }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        table tbody tr:hover {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            transform: scale(1.01);
        }

        table tbody tr:last-child td {
            border-bottom: none;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }

        .empty-icon {
            font-size: 60px;
            margin-bottom: 15px;
            opacity: 0.5;
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 32px;
            background: white;
            color: #667eea;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-top: 25px;
            animation: fadeIn 0.6s ease-out 0.8s both;
        }

        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            background: #f8f9fa;
        }

        .back-btn:active {
            transform: translateY(-1px);
        }

        .back-btn-wrapper {
            text-align: center;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .page-header {
                padding: 25px 20px;
            }

            .profile-icon {
                width: 80px;
                height: 80px;
                font-size: 40px;
                margin-bottom: 16px;
            }

            .box {
                padding: 25px 20px;
            }

            .info-row {
                grid-template-columns: 1fr;
                gap: 8px;
                padding: 14px 0;
            }

            .info-label {
                font-weight: 700;
                color: #2c3e50;
            }

            .info-value {
                padding: 10px 14px;
            }

            table th,
            table td {
                padding: 12px 10px;
                font-size: 13px;
            }

            .back-btn {
                width: 100%;
                justify-content: center;
                padding: 16px 28px;
            }
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Page Load Animation */
        @keyframes pageLoad {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        body {
            animation: pageLoad 0.5s ease-out;
        }

        /* Focus Visible for Accessibility */
        *:focus-visible {
            outline: 3px solid #667eea;
            outline-offset: 2px;
        }

        /* Subject Badge */
        .subject-badge {
            display: inline-block;
            padding: 6px 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px;
            font-weight: 600;
            font-size: 13px;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        /* Stats Summary */
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .stat-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 20px;
            border-radius: 14px;
            text-align: center;
            border: 2px solid #e0e4e8;
        }

        .stat-card h4 {
            color: #667eea;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }

        .stat-card p {
            color: #2c3e50;
            font-size: 24px;
            font-weight: 700;
        }
    </style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <div class="profile-icon">👨‍🏫</div>
        <h2><?= htmlspecialchars($faculty['full_name']); ?></h2>
        <p>Faculty Profile</p>
    </div>

    <!-- BASIC DETAILS -->
    <div class="box">
        <h3>📋 Basic Information</h3>
        
        <div class="info-grid">
            <div class="info-row">
                <div class="info-label" data-icon="👤">Full Name</div>
                <div class="info-value"><?= htmlspecialchars($faculty['full_name']) ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="📧">Email</div>
                <div class="info-value"><?= htmlspecialchars($faculty['email']) ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="📱">Mobile</div>
                <div class="info-value"><?= htmlspecialchars($faculty['mobile']) ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="🎓">Qualification</div>
                <div class="info-value"><?= htmlspecialchars($faculty['qualification']) ?></div>
            </div>

            <div class="info-row">
                <div class="info-label" data-icon="📚">Courses Teaching</div>
                <div class="info-value"><?= htmlspecialchars($faculty['courses']) ?></div>
            </div>
        </div>
    </div>

    <!-- SUBJECT DETAILS -->
    <div class="box">
        <h3>📘 Assigned Subjects</h3>

        <?php if ($subjects->num_rows > 0) { ?>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Course</th>
                            <th>Subject Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $subjects->fetch_assoc()) { ?>
                        <tr>
                            <td>
                                <span class="subject-badge"><?= htmlspecialchars($row['course']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($row['subject_name']) ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        <?php } else { ?>
            <div class="empty-state">
                <div class="empty-icon">📚</div>
                <p>No subjects assigned yet.</p>
            </div>
        <?php } ?>
    </div>

    <div class="back-btn-wrapper">
        <a href="dashboard.php" class="back-btn">
            <span>⬅</span>
            <span>Back to Dashboard</span>
        </a>
    </div>

</div>

</body>
</html>